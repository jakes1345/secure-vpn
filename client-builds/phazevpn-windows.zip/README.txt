PhazeVPN Client Downloads
=========================

Installation Instructions:

Windows:
1. Run install-windows.bat as Administrator
2. Or manually copy phazevpn-windows-amd64.exe to C:\Program Files\PhazeVPN\

macOS:
1. Run: ./install-macos.sh
2. Or manually: sudo cp phazevpn-macos-* /usr/local/bin/phazevpn

Linux:
1. Run: ./install-linux.sh
2. Or manually: sudo cp phazevpn-linux-* /usr/local/bin/phazevpn

Usage:
1. Download your config from https://phazevpn.com/dashboard
2. Run: phazevpn -config phazevpn.conf

For support: https://phazevpn.com/contact
