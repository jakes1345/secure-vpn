#!/bin/bash
echo "Installing PhazeVPN..."
sudo cp phazevpn-macos-* /usr/local/bin/phazevpn
sudo chmod +x /usr/local/bin/phazevpn
echo "✅ Installed! Run: phazevpn"
