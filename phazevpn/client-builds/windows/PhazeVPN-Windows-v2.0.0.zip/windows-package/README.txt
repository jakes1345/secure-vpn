PhazeVPN for Windows v2.0.0
===========================

INSTALLATION:
1. Extract to C:\Program Files\PhazeVPN
2. Open Command Prompt as Administrator
3. Run: phazevpn.exe

FEATURES:
✓ Zero-knowledge VPN protocol
✓ Kill switch protection  
✓ Auto-reconnect (5 retries)
✓ Real-time bandwidth stats

REQUIREMENTS:
- Windows 10/11 (64-bit)
- Administrator privileges

SUPPORT:
https://phazevpn.com
support@phazevpn.com
