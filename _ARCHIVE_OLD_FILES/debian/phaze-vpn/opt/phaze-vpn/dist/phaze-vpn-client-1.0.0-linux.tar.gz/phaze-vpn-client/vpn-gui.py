#!/usr/bin/env python3
"""
VPN Desktop Application
A simple GUI for managing your VPN server
"""

import tkinter as tk
from tkinter import ttk, messagebox, scrolledtext, filedialog
import subprocess
import threading
import time
from pathlib import Path
import json
import hashlib
import os
import requests
import urllib3
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

# Import VPS communication helper
try:
    from vps_helper import ssh_to_vps, check_vpn_status as vps_check_status, start_vpn as vps_start_vpn, stop_vpn as vps_stop_vpn
    VPS_HELPER_AVAILABLE = True
except ImportError:
    # Fallback if vps_helper not available
    VPS_HELPER_AVAILABLE = False
    def ssh_to_vps(cmd): return {'success': False, 'output': '', 'error': 'vps_helper not available'}
    def vps_check_status(): return False
    def vps_start_vpn(): return False
    def vps_stop_vpn(): return False

def hash_password(password):
    """Hash a password using SHA256"""
    return hashlib.sha256(password.encode()).hexdigest()
import shutil
import sys
from datetime import datetime

# Import subscription manager
sys.path.insert(0, str(Path(__file__).parent))
try:
    from subscription_manager import (
        get_user_subscription, set_user_subscription, cancel_subscription,
        check_subscription_status, get_tier_info, TIERS,
        create_payment_intent, record_payment, get_revenue_stats
    )
except ImportError:
    # Fallback if subscription manager not available
    def get_user_subscription(username):
        return {'tier': 'free', 'status': 'active'}
    def get_tier_info(tier):
        return {'name': tier.title(), 'price': 0, 'price_display': 'Free'}
    TIERS = {}

# Try installed locations first, then current directory
# PhazeVPN installation paths (check in order of preference)
if Path('/opt/secure-vpn/vpn-manager.py').exists():
    # VPS uses /opt/secure-vpn (legacy name, but that's what's on VPS)
    VPN_DIR = Path('/opt/secure-vpn')
elif Path('/opt/phazevpn/vpn-manager.py').exists():
    VPN_DIR = Path('/opt/phazevpn')
elif Path('/opt/phaze-vpn/vpn-gui.py').exists():
    VPN_DIR = Path('/opt/phaze-vpn')
else:
    # Local development - use current directory
    VPN_DIR = Path(__file__).parent

STATUS_LOG = VPN_DIR / 'logs' / 'status.log'
SERVER_LOG = VPN_DIR / 'logs' / 'server.log'
USERS_FILE = VPN_DIR / 'users.json'

# ============================================
# VPS API CONFIGURATION
# ============================================
# VPS API URL - Try to detect from environment or use default
VPS_API_URL = os.environ.get('VPS_API_URL', 'https://phazevpn.com')
# Fallback URLs if primary doesn't work
VPS_API_FALLBACKS = [
    'https://phazevpn.com',
    'https://phazevpn.duckdns.org',
    'http://15.204.11.19:5000',  # Direct IP fallback
]
# Use VPS API by default (set to False for offline/local-only mode)
USE_VPS_API = os.environ.get('USE_VPS_API', 'true').lower() == 'true'
# Timeout for API requests (seconds)
API_TIMEOUT = 10

# ============================================
# VPS API AUTHENTICATION FUNCTIONS
# ============================================

def authenticate_vps_api(username, password):
    """Authenticate user against VPS API"""
    if not USE_VPS_API:
        return None, "VPS API disabled"
    
    for api_url in [VPS_API_URL] + VPS_API_FALLBACKS:
        try:
            login_url = f"{api_url}/api/app/login"
            response = requests.post(
                login_url,
                json={'username': username, 'password': password},
                timeout=API_TIMEOUT,
                verify=False  # Allow self-signed certs
            )
            
            if response.status_code == 200:
                data = response.json()
                if data.get('success'):
                    user_info = data.get('user', {})
                    return {
                        'success': True,
                        'username': user_info.get('username', username),
                        'role': user_info.get('role', 'user'),
                        'subscription': data.get('subscription', {})
                    }, None
                else:
                    return None, data.get('error', 'Authentication failed')
            elif response.status_code == 401:
                return None, "Invalid username or password"
            else:
                # Try next fallback URL
                continue
        except requests.exceptions.Timeout:
            continue  # Try next URL
        except requests.exceptions.ConnectionError:
            continue  # Try next URL
        except Exception as e:
            continue  # Try next URL
    
    return None, "Unable to connect to VPS. Please check your internet connection."

def create_user_vps_api(username, password, email=None, role='user'):
    """Create user on VPS via API"""
    if not USE_VPS_API:
        return None, "VPS API disabled"
    
    for api_url in [VPS_API_URL] + VPS_API_FALLBACKS:
        try:
            # Try the app signup endpoint first (public, no auth required)
            signup_url = f"{api_url}/api/app/signup"
            signup_data = {
                'username': username,
                'password': password,
                'confirm_password': password,
                'email': email or f"{username}@phazevpn.local"
            }
            
            response = requests.post(
                signup_url,
                json=signup_data,
                timeout=API_TIMEOUT,
                verify=False
            )
            
            if response.status_code in [200, 201]:
                try:
                    data = response.json()
                    if data.get('success'):
                        return {'success': True, 'message': data.get('message')}, None
                except:
                    return {'success': True}, None
            elif response.status_code == 409:
                return None, "Username or email already exists"
            elif response.status_code == 400:
                try:
                    data = response.json()
                    return None, data.get('error', 'Validation failed')
                except:
                    return None, "Validation failed"
            else:
                continue
        except requests.exceptions.Timeout:
            continue
        except requests.exceptions.ConnectionError:
            continue
        except Exception:
            continue
    
    return None, "Unable to connect to VPS for signup"

# ============================================
# USER MANAGEMENT FUNCTIONS
# ============================================

def load_users():
    """Load users from JSON file"""
    if USERS_FILE.exists():
        try:
            with open(USERS_FILE) as f:
                return json.load(f)
        except:
            pass
    # Default users if file doesn't exist
    return {
        "users": {
            "admin": {"password": "admin123", "role": "admin", "created": "2025-11-19"},
            "moderator": {"password": "mod123", "role": "moderator", "created": "2025-11-19"},
            "user": {"password": "user123", "role": "user", "created": "2025-11-19"},
            "premium": {"password": "premium123", "role": "premium", "created": "2025-11-19"}
        },
        "roles": {
            "admin": {
                "can_start_stop_vpn": True, "can_edit_server_config": True,
                "can_manage_clients": True, "can_view_logs": True,
                "can_view_statistics": True, "can_export_configs": True,
                "can_backup": True, "can_disconnect_clients": True,
                "can_revoke_clients": True, "can_add_clients": True,
                "can_edit_clients": True, "can_start_download_server": True,
                "can_manage_users": True
            },
            "moderator": {
                "can_start_stop_vpn": False, "can_edit_server_config": False,
                "can_manage_clients": True, "can_view_logs": True,
                "can_view_statistics": True, "can_export_configs": True,
                "can_backup": False, "can_disconnect_clients": True,
                "can_revoke_clients": False, "can_add_clients": True,
                "can_edit_clients": True, "can_start_download_server": True,
                "can_manage_users": False
            },
            "premium": {
                "can_start_stop_vpn": False, "can_edit_server_config": False,
                "can_manage_clients": False, "can_view_logs": True,
                "can_view_statistics": True, "can_export_configs": True,
                "can_backup": False, "can_disconnect_clients": False,
                "can_revoke_clients": False, "can_add_clients": False,
                "can_edit_clients": False, "can_start_download_server": False,
                "can_manage_users": False
            },
            "user": {
                "can_start_stop_vpn": False, "can_edit_server_config": False,
                "can_manage_clients": False, "can_view_logs": False,
                "can_view_statistics": True, "can_export_configs": False,
                "can_backup": False, "can_disconnect_clients": False,
                "can_revoke_clients": False, "can_add_clients": False,
                "can_edit_clients": False, "can_start_download_server": False,
                "can_manage_users": False
            }
        }
    }

def save_users(users_data):
    """Save users to JSON file"""
    with open(USERS_FILE, 'w') as f:
        json.dump(users_data, f, indent=2)

def get_user_role(username):
    """Get role for a user"""
    users_data = load_users()
    if username in users_data.get("users", {}):
        return users_data["users"][username].get("role", "user")
    return "user"

def get_permissions(role):
    """Get permissions for a role"""
    users_data = load_users()
    return users_data.get("roles", {}).get(role, users_data.get("roles", {}).get("user", {}))

# Default credentials (for backward compatibility)
DEFAULT_USERNAME = 'admin'
DEFAULT_PASSWORD = 'admin123'  # ⚠️ CHANGE THIS IN PRODUCTION!

class LoginWindow:
    def __init__(self):
        self.root = tk.Tk()
        self.root.title("PhazeVPN - Login")
        self.root.geometry("400x300")
        self.root.resizable(False, False)
        self.root.configure(bg='#2b2b2b')
        
        # Center window
        self.center_window()
        
        # Login frame
        frame = tk.Frame(self.root, bg='#2b2b2b', padx=40, pady=40)
        frame.pack(fill=tk.BOTH, expand=True)
        
        # Logo and branding
        logo_frame = tk.Frame(frame, bg='#2b2b2b')
        logo_frame.pack(pady=(0, 20))
        
        # Try to load logo
        try:
            logo_path = None
            for path in [
                VPN_DIR / 'assets' / 'icons' / 'phazevpn-128x128.png',
                Path(__file__).parent / 'assets' / 'icons' / 'phazevpn-128x128.png',
            ]:
                if path.exists():
                    logo_path = path
                    break
            
            if logo_path:
                logo_img = tk.PhotoImage(file=str(logo_path))
                logo_label = tk.Label(logo_frame, image=logo_img, bg='#2b2b2b')
                logo_label.image = logo_img  # Keep reference
                logo_label.pack(pady=(0, 15))
        except:
            pass
        
        # Professional title
        title = tk.Label(frame, text="PhazeVPN", 
                        font=('Arial', 32, 'bold'), 
                        bg='#2b2b2b', fg='#ffffff')
        title.pack(pady=(0, 5))
        
        subtitle = tk.Label(frame, text="Professional VPN Management", 
                          font=('Arial', 14),
                          bg='#2b2b2b', fg='#888888')
        subtitle.pack(pady=(0, 30))
        
        # Username
        tk.Label(frame, text="Username:", bg='#2b2b2b', fg='#ffffff',
                font=('Arial', 11)).pack(anchor='w', pady=(0, 5))
        self.username_entry = tk.Entry(frame, font=('Arial', 12), width=25)
        self.username_entry.pack(pady=(0, 15))
        self.username_entry.focus()
        
        # Password
        tk.Label(frame, text="Password:", bg='#2b2b2b', fg='#ffffff',
                font=('Arial', 11)).pack(anchor='w', pady=(0, 5))
        self.password_entry = tk.Entry(frame, font=('Arial', 12), 
                                      show='*', width=25)
        self.password_entry.pack(pady=(0, 20))
        self.password_entry.bind('<Return>', lambda e: self.login())
        
        # Login button
        login_btn = tk.Button(frame, text="Login", 
                             command=self.login,
                             bg='#667eea', fg='white',
                             font=('Arial', 12, 'bold'),
                             width=20, height=2,
                             cursor='hand2',
                             relief=tk.FLAT)
        login_btn.pack(pady=(0, 10))
        
        # Sign up link
        signup_frame = tk.Frame(frame, bg='#2b2b2b')
        signup_frame.pack(pady=(0, 10))
        
        tk.Label(signup_frame, text="Don't have an account? ", 
                bg='#2b2b2b', fg='#aaaaaa',
                font=('Arial', 10)).pack(side=tk.LEFT)
        
        signup_link = tk.Label(signup_frame, text="Sign Up", 
                              bg='#2b2b2b', fg='#667eea',
                              font=('Arial', 10, 'underline'),
                              cursor='hand2')
        signup_link.pack(side=tk.LEFT)
        signup_link.bind('<Button-1>', lambda e: self.show_signup())
        
        # Forgot password link
        forgot_frame = tk.Frame(frame, bg='#2b2b2b')
        forgot_frame.pack()
        
        forgot_link = tk.Label(forgot_frame, text="Forgot Password?", 
                              bg='#2b2b2b', fg='#667eea',
                              font=('Arial', 9, 'underline'),
                              cursor='hand2')
        forgot_link.pack()
        forgot_link.bind('<Button-1>', lambda e: self.show_forgot_password())
        
        # Error label
        self.error_label = tk.Label(frame, text="", 
                                   bg='#2b2b2b', fg='#ff4444',
                                   font=('Arial', 10))
        self.error_label.pack(pady=(10, 0))
        
        self.logged_in = False
        
    def center_window(self):
        self.root.update_idletasks()
        width = self.root.winfo_width()
        height = self.root.winfo_height()
        x = (self.root.winfo_screenwidth() // 2) - (width // 2)
        y = (self.root.winfo_screenheight() // 2) - (height // 2)
        self.root.geometry(f'{width}x{height}+{x}+{y}')
    
    def login(self):
        username = self.username_entry.get()
        password = self.password_entry.get()
        
        if not username or not password:
            self.error_label.config(text="Please enter username and password")
            return
        
        # Try VPS API authentication first (if enabled)
        if USE_VPS_API:
            result, error = authenticate_vps_api(username, password)
            if result and result.get('success'):
                # Successfully authenticated against VPS
                self.logged_in = True
                self.username = result.get('username', username)
                self.role = result.get('role', 'user')
                self.root.destroy()
                return
            elif error and "Unable to connect" not in error:
                # Authentication failed (invalid credentials), don't fallback to local
                self.error_label.config(text=error)
                self.password_entry.delete(0, tk.END)
                return
            # If connection error, fall through to local authentication
        
        # Fallback to local authentication (for offline mode or if VPS unavailable)
        users_data = load_users()
        users = users_data.get("users", {})
        
        # SECURE PASSWORD VERIFICATION - Use bcrypt
        if username in users:
            stored_password = users[username].get("password", "")
            
            # Try bcrypt verification first (secure)
            try:
                import bcrypt
                if isinstance(stored_password, str):
                    # Check if it's a bcrypt hash (starts with $2b$)
                    if stored_password.startswith('$2b$') or stored_password.startswith('$2a$'):
                        if bcrypt.checkpw(password.encode('utf-8'), stored_password.encode('utf-8')):
                            self.logged_in = True
                            self.username = username
                            self.role = users[username].get("role", "user")
                            self.root.destroy()
                            return
                    # Legacy SHA256 support (for migration)
                    elif len(stored_password) == 64:  # SHA256 hash length
                        hashed_password = hash_password(password)
                        if stored_password == hashed_password:
                            # Migrate to bcrypt
                            users[username]["password"] = bcrypt.hashpw(password.encode('utf-8'), bcrypt.gensalt(12)).decode('utf-8')
                            save_users(users_data)
                            self.logged_in = True
                            self.username = username
                            self.role = users[username].get("role", "user")
                            self.root.destroy()
                            return
                    # Plain text fallback (for old accounts - migrate immediately)
                    elif stored_password == password:
                        # MIGRATE TO BCRYPT IMMEDIATELY
                        users[username]["password"] = bcrypt.hashpw(password.encode('utf-8'), bcrypt.gensalt(12)).decode('utf-8')
                        save_users(users_data)
                        self.logged_in = True
                        self.username = username
                        self.role = users[username].get("role", "user")
                        self.root.destroy()
                        return
            except ImportError:
                # Fallback if bcrypt not available
                hashed_password = hash_password(password)
                if stored_password == hashed_password or stored_password == password:
                    self.logged_in = True
                    self.username = username
                    self.role = users[username].get("role", "user")
                    self.root.destroy()
                    return
            
            self.error_label.config(text="Invalid username or password")
            self.password_entry.delete(0, tk.END)
        else:
            self.error_label.config(text="Invalid username or password")
            self.password_entry.delete(0, tk.END)
    
    def show_signup(self):
        """Show signup window"""
        SignupWindow(self.root)
    
    def show_forgot_password(self):
        """Show forgot password window"""
        ForgotPasswordWindow(self.root)
    
    def run(self):
        self.root.mainloop()
        if self.logged_in:
            return {
                'logged_in': True,
                'username': getattr(self, 'username', 'admin'),
                'role': getattr(self, 'role', 'admin')
            }
        return {'logged_in': False}

class SignupWindow:
    """User registration window"""
    def __init__(self, parent):
        self.parent = parent
        self.window = tk.Toplevel(parent)
        self.window.title("Sign Up - PhazeVPN")
        self.window.geometry("450x500")
        self.window.configure(bg='#2b2b2b')
        self.window.resizable(False, False)
        
        self.center_window()
        self.setup_ui()
    
    def center_window(self):
        self.window.update_idletasks()
        width = self.window.winfo_width()
        height = self.window.winfo_height()
        x = (self.window.winfo_screenwidth() // 2) - (width // 2)
        y = (self.window.winfo_screenheight() // 2) - (height // 2)
        self.window.geometry(f'{width}x{height}+{x}+{y}')
    
    def setup_ui(self):
        frame = tk.Frame(self.window, bg='#2b2b2b', padx=40, pady=30)
        frame.pack(fill=tk.BOTH, expand=True)
        
        # Title
        tk.Label(frame, text="🚀 Create Account", 
                font=('Arial', 20, 'bold'), 
                bg='#2b2b2b', fg='#ffffff').pack(pady=(0, 25))
        
        # Username
        tk.Label(frame, text="Username:", bg='#2b2b2b', fg='#ffffff',
                font=('Arial', 11)).pack(anchor='w', pady=(0, 5))
        self.username_entry = tk.Entry(frame, font=('Arial', 12), width=30)
        self.username_entry.pack(pady=(0, 15))
        
        # Email
        tk.Label(frame, text="Email:", bg='#2b2b2b', fg='#ffffff',
                font=('Arial', 11)).pack(anchor='w', pady=(0, 5))
        self.email_entry = tk.Entry(frame, font=('Arial', 12), width=30)
        self.email_entry.pack(pady=(0, 15))
        
        # Password
        tk.Label(frame, text="Password:", bg='#2b2b2b', fg='#ffffff',
                font=('Arial', 11)).pack(anchor='w', pady=(0, 5))
        self.password_entry = tk.Entry(frame, font=('Arial', 12), 
                                      show='*', width=30)
        self.password_entry.pack(pady=(0, 15))
        
        # Confirm Password
        tk.Label(frame, text="Confirm Password:", bg='#2b2b2b', fg='#ffffff',
                font=('Arial', 11)).pack(anchor='w', pady=(0, 5))
        self.confirm_entry = tk.Entry(frame, font=('Arial', 12), 
                                     show='*', width=30)
        self.confirm_entry.pack(pady=(0, 20))
        
        # Error label
        self.error_label = tk.Label(frame, text="", 
                                   bg='#2b2b2b', fg='#ff4444',
                                   font=('Arial', 10))
        self.error_label.pack(pady=(0, 10))
        
        # Sign up button
        tk.Button(frame, text="Sign Up", 
                 command=self.signup,
                 bg='#4caf50', fg='white',
                 font=('Arial', 12, 'bold'),
                 width=20, height=2,
                 cursor='hand2',
                 relief=tk.FLAT).pack(pady=(0, 10))
        
        # Back to login
        back_link = tk.Label(frame, text="← Back to Login", 
                            bg='#2b2b2b', fg='#667eea',
                            font=('Arial', 10, 'underline'),
                            cursor='hand2')
        back_link.pack()
        back_link.bind('<Button-1>', lambda e: self.window.destroy())
    
    def signup(self):
        username = self.username_entry.get().strip()
        email = self.email_entry.get().strip()
        password = self.password_entry.get()
        confirm = self.confirm_entry.get()
        
        # Validation
        if not username or not email or not password:
            self.error_label.config(text="All fields are required")
            return
        
        if password != confirm:
            self.error_label.config(text="Passwords do not match")
            return
        
        if len(password) < 6:
            self.error_label.config(text="Password must be at least 6 characters")
            return
        
        # Try VPS API signup first (if enabled)
        if USE_VPS_API:
            result, error = create_user_vps_api(username, password, email)
            if result and result.get('success'):
                messagebox.showinfo("Success", 
                                  f"Account created successfully!\n\n"
                                  f"Username: {username}\n"
                                  f"Please check your email to verify your account.\n"
                                  f"You can now login with your credentials.")
                self.window.destroy()
                return
            elif error:
                if "Unable to connect" in error:
                    # If connection error, ask if user wants to create local account
                    if messagebox.askyesno("VPS Unavailable", 
                                          "Unable to connect to VPS server.\n\n"
                                          "Would you like to create a local account instead?\n"
                                          "(This account will only work offline)"):
                        # Fall through to local signup
                        pass
                    else:
                        return
                else:
                    # Other error (validation, user exists, etc.)
                    self.error_label.config(text=error)
                    return
        
        # Fallback to local signup (for offline mode or if VPS unavailable)
        users_data = load_users()
        if username in users_data.get("users", {}):
            self.error_label.config(text="Username already exists")
            return
        
        # Hash password before storing (CRITICAL for security)
        try:
            import bcrypt
            hashed_password = bcrypt.hashpw(password.encode('utf-8'), bcrypt.gensalt(12)).decode('utf-8')
        except ImportError:
            hashed_password = hash_password(password)
        
        # Create user
        users_data["users"][username] = {
            "password": hashed_password,  # Store hashed password
            "email": email,
            "role": "user",  # Default to free user
            "created": datetime.now().strftime("%Y-%m-%d"),
            "verified": False  # Email verification needed
        }
        
        save_users(users_data)
        
        # Initialize subscription (free tier)
        try:
            from subscription_manager import set_user_subscription
            set_user_subscription(username, 'free')
        except:
            pass
        
        messagebox.showinfo("Success", 
                          f"Local account created successfully!\n\n"
                          f"Username: {username}\n"
                          f"Note: This is a local account. For full features, connect to VPS.")
        self.window.destroy()

class ForgotPasswordWindow:
    """Password reset window"""
    def __init__(self, parent):
        self.parent = parent
        self.window = tk.Toplevel(parent)
        self.window.title("Reset Password - PhazeVPN")
        self.window.geometry("400x250")
        self.window.configure(bg='#2b2b2b')
        self.window.resizable(False, False)
        
        self.center_window()
        self.setup_ui()
    
    def center_window(self):
        self.window.update_idletasks()
        width = self.window.winfo_width()
        height = self.window.winfo_height()
        x = (self.window.winfo_screenwidth() // 2) - (width // 2)
        y = (self.window.winfo_screenheight() // 2) - (height // 2)
        self.window.geometry(f'{width}x{height}+{x}+{y}')
    
    def setup_ui(self):
        frame = tk.Frame(self.window, bg='#2b2b2b', padx=40, pady=30)
        frame.pack(fill=tk.BOTH, expand=True)
        
        tk.Label(frame, text="🔑 Reset Password", 
                font=('Arial', 18, 'bold'), 
                bg='#2b2b2b', fg='#ffffff').pack(pady=(0, 20))
        
        tk.Label(frame, text="Enter your username:", 
                bg='#2b2b2b', fg='#ffffff',
                font=('Arial', 11)).pack(anchor='w', pady=(0, 5))
        
        self.username_entry = tk.Entry(frame, font=('Arial', 12), width=25)
        self.username_entry.pack(pady=(0, 20))
        
        self.error_label = tk.Label(frame, text="", 
                                   bg='#2b2b2b', fg='#ff4444',
                                   font=('Arial', 10))
        self.error_label.pack(pady=(0, 10))
        
        tk.Button(frame, text="Reset Password", 
                 command=self.reset_password,
                 bg='#ff9800', fg='white',
                 font=('Arial', 11, 'bold'),
                 width=20,
                 cursor='hand2',
                 relief=tk.FLAT).pack(pady=(0, 10))
        
        back_link = tk.Label(frame, text="← Back to Login", 
                            bg='#2b2b2b', fg='#667eea',
                            font=('Arial', 10, 'underline'),
                            cursor='hand2')
        back_link.pack()
        back_link.bind('<Button-1>', lambda e: self.window.destroy())
    
    def reset_password(self):
        username = self.username_entry.get().strip()
        
        if not username:
            self.error_label.config(text="Please enter your username")
            return
        
        users_data = load_users()
        if username not in users_data.get("users", {}):
            self.error_label.config(text="Username not found")
            return
        
        # In production, send email with reset link
        # For now, show admin contact
        messagebox.showinfo("Password Reset", 
                          f"Password reset requested for: {username}\n\n"
                          f"In production, a reset link would be sent to your email.\n\n"
                          f"For now, contact your administrator to reset your password.")
        self.window.destroy()

class ToolTip:
    def __init__(self, widget, text):
        self.widget = widget
        self.text = text
        self.tipwindow = None
        self.widget.bind('<Enter>', self.enter)
        self.widget.bind('<Leave>', self.leave)
    
    def enter(self, event=None):
        self.show_tooltip()
    
    def leave(self, event=None):
        self.hide_tooltip()
    
    def show_tooltip(self):
        x, y, _, _ = self.widget.bbox("insert") if hasattr(self.widget, 'bbox') else (0, 0, 0, 0)
        x += self.widget.winfo_rootx() + 25
        y += self.widget.winfo_rooty() + 20
        
        self.tipwindow = tw = tk.Toplevel(self.widget)
        tw.wm_overrideredirect(True)
        tw.wm_geometry(f"+{x}+{y}")
        
        label = tk.Label(tw, text=self.text, background="#ffffe0",
                        relief=tk.SOLID, borderwidth=1,
                        font=("Arial", 9))
        label.pack()
    
    def hide_tooltip(self):
        tw = self.tipwindow
        self.tipwindow = None
        if tw:
            tw.destroy()

class VPNDashboard:
    def __init__(self, username='admin', role='admin', password=None):
        self.root = tk.Tk()
        self.username = username
        self.role = role
        self.permissions = get_permissions(role)
        
        # VPS Configuration
        self.vps_host = "15.204.11.19"
        self.vps_user = "root"
        self.vps_password = "Jakes1328!@"
        
        # API configuration - use web portal API to control VPS VPN
        self.api_base_url = "https://phazevpn.com"  # Updated to use real domain
        self.api_session = requests.Session()
        self.api_session.verify = False  # Self-signed cert
        self.api_session.timeout = 10
        self.api_authenticated = False
        
        # Store password for API authentication
        self.password = password
        
        # Authenticate with web portal API if password provided
        if password:
            self._authenticate_api(username, password)
        
        # Download server integration
        self.download_server_port = 8081
        self.download_server_running = False
        self.download_server_process = None
        
        role_title = role.upper() if role != 'user' else 'VIEWER'
        self.root.title(f"PhazeVPN Dashboard - {role_title} Mode")
        self.root.geometry("1200x850")
        self.root.configure(bg='#1a1a1a')
        
        # Set professional window icon
        try:
            icon_paths = [
                VPN_DIR / 'assets' / 'icons' / 'phazevpn.png',
                VPN_DIR / 'assets' / 'icons' / 'phazevpn-256x256.png',
                VPN_DIR / 'assets' / 'icons' / 'phazevpn-icon.png',
                Path(__file__).parent / 'assets' / 'icons' / 'phazevpn.png',
            ]
            for icon_path in icon_paths:
                if icon_path.exists():
                    self.root.iconphoto(True, tk.PhotoImage(file=str(icon_path)))
                    break
        except Exception as e:
            print(f"Could not load icon: {e}")  # Silent fail - app still works
        
        # Keyboard shortcuts
        self.root.bind('<F5>', lambda e: self.update_status())
        self.root.bind('<Control-q>', lambda e: self.logout())
        if self.permissions.get('can_backup', False):
            self.root.bind('<Control-s>', lambda e: self.backup_config())
        
        # Connection history for graphs
        self.connection_history = []
        self.max_history = 50
        
        self.setup_ui()
        self.update_status()
        self.start_auto_refresh()
        
    def setup_ui(self):
        # Header
        header = tk.Frame(self.root, bg='#2b2b2b', height=60)
        header.pack(fill=tk.X, padx=0, pady=0)
        
        # Title with role badge
        title_frame = tk.Frame(header, bg='#2b2b2b')
        title_frame.pack(side=tk.LEFT, padx=20, pady=15)
        
        # Professional logo/icon display
        try:
            logo_path = None
            for path in [
                VPN_DIR / 'assets' / 'icons' / 'phazevpn-64x64.png',
                Path(__file__).parent / 'assets' / 'icons' / 'phazevpn-64x64.png',
            ]:
                if path.exists():
                    logo_path = path
                    break
            
            if logo_path:
                logo_img = tk.PhotoImage(file=str(logo_path))
                logo_label = tk.Label(title_frame, image=logo_img, bg='#2b2b2b')
                logo_label.image = logo_img  # Keep reference
                logo_label.pack(side=tk.LEFT, padx=(0, 10))
        except:
            pass
        
        title = tk.Label(title_frame, text="PhazeVPN", 
                        font=('Arial', 22, 'bold'),
                        bg='#2b2b2b', fg='#ffffff')
        title.pack(side=tk.LEFT)
        
        subtitle = tk.Label(title_frame, text="Dashboard", 
                          font=('Arial', 14),
                          bg='#2b2b2b', fg='#aaaaaa')
        subtitle.pack(side=tk.LEFT, padx=(5, 0))
        
        # Role badge
        role_colors = {
            'admin': '#f44336',
            'moderator': '#ff9800',
            'premium': '#9c27b0',
            'user': '#2196F3'
        }
        role_color = role_colors.get(self.role, '#666')
        role_label = tk.Label(title_frame, text=f" {self.role.upper()} ", 
                             font=('Arial', 10, 'bold'),
                             bg=role_color, fg='white',
                             relief=tk.RAISED, padx=8, pady=2)
        role_label.pack(side=tk.LEFT, padx=(10, 0))
        
        # User name
        user_label = tk.Label(title_frame, text=f"👤 {self.username}", 
                             font=('Arial', 11),
                             bg='#2b2b2b', fg='#aaaaaa')
        user_label.pack(side=tk.LEFT, padx=(10, 0))
        
        # Header buttons (role-based)
        header_btn_frame = tk.Frame(header, bg='#2b2b2b')
        header_btn_frame.pack(side=tk.RIGHT, padx=10)
        
        if self.permissions.get('can_edit_server_config', False):
            tk.Button(header_btn_frame, text="⚙️ Server Config", 
                     command=self.edit_server_config,
                     bg='#667eea', fg='white',
                     font=('Arial', 9, 'bold'),
                     relief=tk.FLAT, cursor='hand2',
                     padx=10, pady=5).pack(side=tk.LEFT, padx=5)
        
        if self.permissions.get('can_view_statistics', True):
            tk.Button(header_btn_frame, text="📊 Statistics", 
                     command=self.show_statistics,
                     bg='#9c27b0', fg='white',
                     font=('Arial', 9, 'bold'),
                     relief=tk.FLAT, cursor='hand2',
                     padx=10, pady=5).pack(side=tk.LEFT, padx=5)
        
        if self.permissions.get('can_backup', False):
            tk.Button(header_btn_frame, text="💾 Backup", 
                     command=self.backup_config,
                     bg='#009688', fg='white',
                     font=('Arial', 9, 'bold'),
                     relief=tk.FLAT, cursor='hand2',
                     padx=10, pady=5).pack(side=tk.LEFT, padx=5)
        
        if self.permissions.get('can_manage_users', False):
            tk.Button(header_btn_frame, text="👥 Users", 
                     command=self.manage_users,
                     bg='#e91e63', fg='white',
                     font=('Arial', 9, 'bold'),
                     relief=tk.FLAT, cursor='hand2',
                     padx=10, pady=5).pack(side=tk.LEFT, padx=5)
        
        # Support portal for moderators
        if self.role == 'moderator':
            tk.Button(header_btn_frame, text="💬 Support Portal", 
                     command=self.open_support_portal,
                     bg='#00bcd4', fg='white',
                     font=('Arial', 9, 'bold'),
                     relief=tk.FLAT, cursor='hand2',
                     padx=10, pady=5).pack(side=tk.LEFT, padx=5)
        
        # Subscription management (for all users)
        tk.Button(header_btn_frame, text="💳 Subscription", 
                 command=self.manage_subscription,
                 bg='#9c27b0', fg='white',
                 font=('Arial', 9, 'bold'),
                 relief=tk.FLAT, cursor='hand2',
                 padx=10, pady=5).pack(side=tk.LEFT, padx=5)
        
        tk.Button(header_btn_frame, text="❓ Help", 
                 command=self.show_help,
                 bg='#607d8b', fg='white',
                 font=('Arial', 9, 'bold'),
                 relief=tk.FLAT, cursor='hand2',
                 padx=10, pady=5).pack(side=tk.LEFT, padx=5)
        
        logout_btn = tk.Button(header_btn_frame, text="Logout", 
                              command=self.logout,
                              bg='#ff4444', fg='white',
                              font=('Arial', 10, 'bold'),
                              relief=tk.FLAT, cursor='hand2',
                              padx=15, pady=5)
        logout_btn.pack(side=tk.LEFT, padx=5)
        
        # Main container
        main_frame = tk.Frame(self.root, bg='#1a1a1a')
        main_frame.pack(fill=tk.BOTH, expand=True, padx=20, pady=20)
        
        # Status frame
        status_frame = tk.LabelFrame(main_frame, text="Server Status", 
                                     bg='#2b2b2b', fg='#ffffff',
                                     font=('Arial', 12, 'bold'),
                                     padx=15, pady=15)
        status_frame.pack(fill=tk.X, pady=(0, 15))
        
        self.status_label = tk.Label(status_frame, text="Checking...", 
                                    font=('Arial', 14),
                                    bg='#2b2b2b', fg='#ffffff')
        self.status_label.pack(side=tk.LEFT, padx=10)
        
        self.connections_label = tk.Label(status_frame, text="Connections: 0", 
                                          font=('Arial', 12),
                                          bg='#2b2b2b', fg='#aaaaaa')
        self.connections_label.pack(side=tk.LEFT, padx=20)
        
        refresh_btn = tk.Button(status_frame, text="🔄 Refresh", 
                               command=self.update_status,
                               bg='#667eea', fg='white',
                               font=('Arial', 10),
                               relief=tk.FLAT, cursor='hand2',
                               padx=10, pady=5)
        refresh_btn.pack(side=tk.RIGHT)
        self.create_tooltip(refresh_btn, "Refresh status (F5)")
        
        # Control buttons frame (only for admin)
        if self.permissions.get('can_start_stop_vpn', False):
            control_frame = tk.LabelFrame(main_frame, text="Server Controls", 
                                          bg='#2b2b2b', fg='#ffffff',
                                          font=('Arial', 12, 'bold'),
                                          padx=15, pady=15)
            control_frame.pack(fill=tk.X, pady=(0, 15))
            
            btn_frame = tk.Frame(control_frame, bg='#2b2b2b')
            btn_frame.pack()
            
            self.start_btn = tk.Button(btn_frame, text="▶ Start VPN", 
                                       command=self.start_vpn,
                                       bg='#4caf50', fg='white',
                                       font=('Arial', 11, 'bold'),
                                       width=15, height=2,
                                       relief=tk.FLAT, cursor='hand2')
            self.start_btn.pack(side=tk.LEFT, padx=5)
            
            self.stop_btn = tk.Button(btn_frame, text="⏹ Stop VPN", 
                                      command=self.stop_vpn,
                                      bg='#f44336', fg='white',
                                      font=('Arial', 11, 'bold'),
                                      width=15, height=2,
                                      relief=tk.FLAT, cursor='hand2')
            self.stop_btn.pack(side=tk.LEFT, padx=5)
            
            self.restart_btn = tk.Button(btn_frame, text="🔄 Restart VPN", 
                                         command=self.restart_vpn,
                                         bg='#ff9800', fg='white',
                                         font=('Arial', 11, 'bold'),
                                         width=15, height=2,
                                         relief=tk.FLAT, cursor='hand2')
            self.restart_btn.pack(side=tk.LEFT, padx=5)
            
            if self.permissions.get('can_edit_server_config', False):
                tk.Button(btn_frame, text="⚙️ Server Settings", 
                         command=self.edit_server_config,
                         bg='#667eea', fg='white',
                         font=('Arial', 11, 'bold'),
                         width=15, height=2,
                         relief=tk.FLAT, cursor='hand2').pack(side=tk.LEFT, padx=5)
        else:
            # For non-admin users, show read-only status
            control_frame = tk.LabelFrame(main_frame, text="Server Status (Read-Only)", 
                                          bg='#2b2b2b', fg='#ffffff',
                                          font=('Arial', 12, 'bold'),
                                          padx=15, pady=15)
            control_frame.pack(fill=tk.X, pady=(0, 15))
            
            info_label = tk.Label(control_frame, 
                                 text="You don't have permission to control the VPN server",
                                 bg='#2b2b2b', fg='#aaaaaa',
                                 font=('Arial', 11))
            info_label.pack(pady=10)
            
            # Dummy buttons for status updates
            self.start_btn = None
            self.stop_btn = None
            self.restart_btn = None
        
        # Client management buttons (role-based)
        if self.permissions.get('can_manage_clients', False) or self.permissions.get('can_export_configs', False):
            client_mgmt_frame = tk.LabelFrame(main_frame, text="Client Management", 
                                             bg='#2b2b2b', fg='#ffffff',
                                             font=('Arial', 12, 'bold'),
                                             padx=15, pady=15)
            client_mgmt_frame.pack(fill=tk.X, pady=(0, 15))
            
            client_btn_frame = tk.Frame(client_mgmt_frame, bg='#2b2b2b')
            client_btn_frame.pack()
            
            if self.permissions.get('can_add_clients', False):
                tk.Button(client_btn_frame, text="➕ Add New Client", 
                         command=self.add_client,
                         bg='#4caf50', fg='white',
                         font=('Arial', 10, 'bold'),
                         width=18, relief=tk.FLAT, cursor='hand2').pack(side=tk.LEFT, padx=5)
            
            if self.permissions.get('can_manage_clients', False):
                tk.Button(client_btn_frame, text="📋 View All Clients", 
                         command=self.view_all_clients,
                         bg='#2196F3', fg='white',
                         font=('Arial', 10, 'bold'),
                         width=18, relief=tk.FLAT, cursor='hand2').pack(side=tk.LEFT, padx=5)
                
                tk.Button(client_btn_frame, text="⚙️ Client Settings", 
                         command=self.client_settings,
                         bg='#ff9800', fg='white',
                         font=('Arial', 10, 'bold'),
                         width=18, relief=tk.FLAT, cursor='hand2').pack(side=tk.LEFT, padx=5)
            
            if self.permissions.get('can_export_configs', False):
                tk.Button(client_btn_frame, text="📤 Export Config", 
                         command=self.export_client_config,
                         bg='#009688', fg='white',
                         font=('Arial', 10, 'bold'),
                         width=18, relief=tk.FLAT, cursor='hand2').pack(side=tk.LEFT, padx=5)
            
            if self.permissions.get('can_start_download_server', False):
                tk.Button(client_btn_frame, text="🌐 Start Download Server", 
                         command=self.start_download_server,
                         bg='#e91e63', fg='white',
                         font=('Arial', 10, 'bold'),
                         width=18, relief=tk.FLAT, cursor='hand2').pack(side=tk.LEFT, padx=5)
        
        # Connections frame
        conn_frame = tk.LabelFrame(main_frame, text="Active Connections (Right-click for options)", 
                                   bg='#2b2b2b', fg='#ffffff',
                                   font=('Arial', 12, 'bold'),
                                   padx=15, pady=15)
        conn_frame.pack(fill=tk.BOTH, expand=True, pady=(0, 15))
        
        # Treeview for connections
        tree_frame = tk.Frame(conn_frame, bg='#2b2b2b')
        tree_frame.pack(fill=tk.BOTH, expand=True)
        
        columns = ('Name', 'Real IP', 'VPN IP', 'Bytes RX', 'Bytes TX', 'Connected')
        self.tree = ttk.Treeview(tree_frame, columns=columns, show='headings', height=8)
        
        for col in columns:
            self.tree.heading(col, text=col)
            self.tree.column(col, width=120)
        
        # Right-click context menu (role-based)
        self.context_menu = tk.Menu(self.root, tearoff=0, bg='#2b2b2b', fg='#ffffff')
        self.context_menu.add_command(label="📊 View Details", command=self.view_client_details)
        
        if self.permissions.get('can_disconnect_clients', False):
            self.context_menu.add_command(label="🔌 Disconnect", command=self.disconnect_client)
        
        if self.permissions.get('can_edit_clients', False):
            self.context_menu.add_command(label="📝 Edit Config", command=self.edit_client_config)
        
        if self.permissions.get('can_revoke_clients', False):
            self.context_menu.add_command(label="🗑️ Revoke Access", command=self.revoke_client)
        
        self.tree.bind("<Button-3>", self.show_context_menu)
        self.tree.bind("<Double-1>", lambda e: self.view_client_details())
        
        scrollbar = ttk.Scrollbar(tree_frame, orient=tk.VERTICAL, command=self.tree.yview)
        self.tree.configure(yscrollcommand=scrollbar.set)
        
        self.tree.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        scrollbar.pack(side=tk.RIGHT, fill=tk.Y)
        
        # Store connections data
        self.connections_data = []
        
        # Logs frame with search (only if permission)
        self.log_text = None
        self.log_search_entry = None
        
        if self.permissions.get('can_view_logs', False):
            logs_frame = tk.LabelFrame(main_frame, text="Server Logs", 
                                      bg='#2b2b2b', fg='#ffffff',
                                      font=('Arial', 12, 'bold'),
                                      padx=15, pady=15)
            logs_frame.pack(fill=tk.BOTH, expand=True)
            
            # Log search bar
            log_search_frame = tk.Frame(logs_frame, bg='#2b2b2b')
            log_search_frame.pack(fill=tk.X, pady=(0, 10))
            
            tk.Label(log_search_frame, text="🔍 Search:", bg='#2b2b2b', fg='#ffffff',
                    font=('Arial', 10)).pack(side=tk.LEFT, padx=(0, 5))
            
            self.log_search_entry = tk.Entry(log_search_frame, font=('Arial', 10), width=30)
            self.log_search_entry.pack(side=tk.LEFT, padx=5)
            self.log_search_entry.bind('<KeyRelease>', self.filter_logs)
            
            tk.Button(log_search_frame, text="Clear", command=self.clear_log_filter,
                     bg='#666', fg='white', font=('Arial', 9),
                     relief=tk.FLAT, cursor='hand2', padx=10, pady=2).pack(side=tk.LEFT, padx=5)
            
            self.log_text = scrolledtext.ScrolledText(logs_frame, 
                                                      bg='#1a1a1a', fg='#00ff00',
                                                      font=('Courier', 9),
                                                      height=8)
            self.log_text.pack(fill=tk.BOTH, expand=True)
        
        # Status bar
        self.status_bar = tk.Label(main_frame, text="Ready | Press F5 to refresh | Ctrl+Q to logout | Ctrl+S to backup",
                                   bg='#2b2b2b', fg='#aaaaaa',
                                   font=('Arial', 9), anchor='w', padx=10, pady=5)
        self.status_bar.pack(fill=tk.X, side=tk.BOTTOM)
        self._update_status_bar()  # Update with API status
        
    def _authenticate_api(self, username, password):
        """Authenticate with web portal API to get session cookie"""
        try:
            # Use the app login API endpoint
            resp = self.api_session.post(
                f"{self.api_base_url}/api/app/login",
                json={'username': username, 'password': password},
                timeout=10
            )
            if resp.status_code == 200:
                self.api_authenticated = True
                self._update_status_bar()
                return True
            else:
                self.api_authenticated = False
                self._update_status_bar()
                return False
        except Exception as e:
            self.api_authenticated = False
            self._update_status_bar()
            return False
    
    def _prompt_api_login(self):
        """Prompt user for web portal API credentials"""
        login_window = tk.Toplevel(self.root)
        login_window.title("Web Portal API Login")
        login_window.geometry("400x200")
        login_window.configure(bg='#1a1a1a')
        login_window.transient(self.root)
        login_window.grab_set()
        
        # Center window
        login_window.update_idletasks()
        x = (login_window.winfo_screenwidth() // 2) - (400 // 2)
        y = (login_window.winfo_screenheight() // 2) - (200 // 2)
        login_window.geometry(f"400x200+{x}+{y}")
        
        result = {'success': False}
        
        tk.Label(login_window, text="Login to Web Portal API", 
                bg='#1a1a1a', fg='#ffffff', font=('Arial', 14, 'bold')).pack(pady=20)
        
        tk.Label(login_window, text="Username:", bg='#1a1a1a', fg='#ffffff').pack(pady=5)
        username_entry = tk.Entry(login_window, width=30)
        username_entry.pack(pady=5)
        username_entry.insert(0, self.username)
        
        tk.Label(login_window, text="Password:", bg='#1a1a1a', fg='#ffffff').pack(pady=5)
        password_entry = tk.Entry(login_window, width=30, show='*')
        password_entry.pack(pady=5)
        password_entry.focus()
        
        error_label = tk.Label(login_window, text="", bg='#1a1a1a', fg='#f44336')
        error_label.pack(pady=5)
        
        def do_login():
            username = username_entry.get().strip()
            password = password_entry.get()
            
            if self._authenticate_api(username, password):
                result['success'] = True
                login_window.destroy()
            else:
                error_label.config(text="Invalid credentials")
        
        def on_enter(event):
            do_login()
        
        password_entry.bind('<Return>', on_enter)
        
        tk.Button(login_window, text="Login", command=do_login,
                 bg='#4caf50', fg='white', font=('Arial', 10, 'bold'),
                 padx=20, pady=5).pack(pady=10)
        
        login_window.wait_window()
        return result['success']
    
    def _update_status_bar(self):
        """Update status bar with API connection status"""
        if hasattr(self, 'status_bar'):
            api_status = "🔐 API Connected" if self.api_authenticated else "⚠️ API Not Connected"
            self.status_bar.config(text=f"Ready | {api_status} | Press F5 to refresh | Ctrl+Q to logout | Ctrl+S to backup")
    
    def is_vpn_running(self):
        """Check VPN status on VPS - BEAUTIFUL AND RELIABLE"""
        # Use VPS helper if available (most reliable)
        if VPS_HELPER_AVAILABLE:
            try:
                return vps_check_status()
            except:
                pass
        
        # Fallback: Direct SSH
        try:
            result = ssh_to_vps('/usr/local/bin/check-vpn-status')
            if result['success']:
                return result['output'].strip() == 'running'
        except:
            pass
        
        # Fallback: Use API
        if hasattr(self, 'api_session') and self.api_authenticated:
            try:
                resp = self.api_session.get(f"{self.api_base_url}/api/vpn/status", timeout=3)
                if resp.status_code == 200:
                    data = resp.json()
                    return data.get('running', False)
            except:
                pass
        
        return False
    
    def update_status(self):
        is_running = self.is_vpn_running()
        
        if is_running:
            self.status_label.config(text="🟢 VPN Server: RUNNING", fg='#4caf50')
            if self.start_btn:
                self.start_btn.config(state=tk.DISABLED)
                self.stop_btn.config(state=tk.NORMAL)
                self.restart_btn.config(state=tk.NORMAL)
        else:
            self.status_label.config(text="🔴 VPN Server: STOPPED", fg='#f44336')
            if self.start_btn:
                self.start_btn.config(state=tk.NORMAL)
                self.stop_btn.config(state=tk.DISABLED)
                self.restart_btn.config(state=tk.DISABLED)
        
        # Update connections
        connections = self.get_connections()
        self.connections_label.config(text=f"Connections: {len(connections)}")
        
        # Update tree
        for item in self.tree.get_children():
            self.tree.delete(item)
        
        self.connections_data = connections  # Store for context menu
        
        # Sort by name for better organization
        connections_sorted = sorted(connections, key=lambda x: x.get('name', 'Unknown'))
        
        for conn in connections_sorted:
            # Color code by data usage
            total_data = conn.get('bytes_rx', 0) + conn.get('bytes_tx', 0)
            item = self.tree.insert('', tk.END, values=(
                conn.get('name', 'Unknown'),
                conn.get('real_ip', 'N/A'),
                conn.get('virtual_ip', 'N/A'),
                self.format_bytes(conn.get('bytes_rx', 0)),
                self.format_bytes(conn.get('bytes_tx', 0)),
                conn.get('connected_since', 'Unknown')
            ))
            
            # Tag high-usage clients
            if total_data > 100 * 1024 * 1024:  # > 100MB
                self.tree.set(item, 'Name', f"🔥 {conn.get('name', 'Unknown')}")
        
        # Store history for graphs
        self.connection_history.append({
            'time': time.time(),
            'count': len(connections),
            'total_data': sum(c.get('bytes_rx', 0) + c.get('bytes_tx', 0) for c in connections)
        })
        if len(self.connection_history) > self.max_history:
            self.connection_history.pop(0)
        
        # Update status bar
        self.status_bar.config(text=f"Ready | {len(connections)} active connections | "
                                   f"Total data: {self.format_bytes(sum(c.get('bytes_rx', 0) + c.get('bytes_tx', 0) for c in connections))} | "
                                   f"Press F5 to refresh | Ctrl+Q to logout")
        
        # Update logs (if permission)
        if self.permissions.get('can_view_logs', False):
            self.update_logs()
    
    def get_connections(self):
        connections = []
        if STATUS_LOG.exists():
            try:
                with open(STATUS_LOG) as f:
                    for line in f:
                        if line.startswith('CLIENT_LIST,'):
                            parts = line.strip().split(',')
                            if len(parts) >= 4:
                                connections.append({
                                    'name': parts[1],
                                    'real_ip': parts[2],
                                    'virtual_ip': parts[3],
                                    'bytes_rx': int(parts[6]) if len(parts) > 6 else 0,
                                    'bytes_tx': int(parts[7]) if len(parts) > 7 else 0,
                                    'connected_since': parts[8] if len(parts) > 8 else 'Unknown'
                                })
            except:
                pass
        return connections
    
    def format_bytes(self, bytes_val):
        for unit in ['B', 'KB', 'MB', 'GB']:
            if bytes_val < 1024.0:
                return f"{bytes_val:.1f} {unit}"
            bytes_val /= 1024.0
        return f"{bytes_val:.1f} TB"
    
    def update_logs(self):
        if self.log_text is None:
            return  # Logs not available for this user
        
        if SERVER_LOG.exists():
            try:
                with open(SERVER_LOG) as f:
                    lines = f.readlines()
                    filtered_lines = lines[-50:]  # Last 50 lines
                    
                    # Apply search filter if active
                    if self.log_search_entry:
                        search_term = self.log_search_entry.get().lower()
                        if search_term:
                            filtered_lines = [l for l in filtered_lines if search_term in l.lower()]
                    
                    self.log_text.delete(1.0, tk.END)
                    self.log_text.insert(tk.END, ''.join(filtered_lines))
                    self.log_text.see(tk.END)
            except:
                pass
    
    def filter_logs(self, event=None):
        if self.log_text:
            self.update_logs()
    
    def clear_log_filter(self):
        if self.log_search_entry:
            self.log_search_entry.delete(0, tk.END)
            self.update_logs()
    
    def _prompt_sudo_password(self):
        """Prompt for sudo password for admin operations"""
        sudo_dialog = tk.Toplevel(self.root)
        sudo_dialog.title("Admin Verification Required")
        sudo_dialog.geometry("400x200")
        sudo_dialog.configure(bg='#2b2b2b')
        sudo_dialog.resizable(False, False)
        sudo_dialog.transient(self.root)
        sudo_dialog.grab_set()
        
        # Center window
        sudo_dialog.update_idletasks()
        x = (sudo_dialog.winfo_screenwidth() // 2) - 200
        y = (sudo_dialog.winfo_screenheight() // 2) - 100
        sudo_dialog.geometry(f"400x200+{x}+{y}")
        
        result = {'password': None, 'cancelled': False}
        
        frame = tk.Frame(sudo_dialog, bg='#2b2b2b', padx=30, pady=30)
        frame.pack(fill=tk.BOTH, expand=True)
        
        tk.Label(frame, text="🔐 Admin Verification", 
                bg='#2b2b2b', fg='#ffffff',
                font=('Arial', 14, 'bold')).pack(pady=(0, 15))
        
        tk.Label(frame, text="Enter your password to verify admin access:", 
                bg='#2b2b2b', fg='#aaaaaa',
                font=('Arial', 10)).pack(pady=(0, 10))
        
        password_entry = tk.Entry(frame, font=('Arial', 12), 
                                 show='*', width=30)
        password_entry.pack(pady=(0, 20))
        password_entry.focus()
        password_entry.bind('<Return>', lambda e: sudo_dialog.quit())
        
        def confirm():
            result['password'] = password_entry.get()
            sudo_dialog.quit()
        
        def cancel():
            result['cancelled'] = True
            sudo_dialog.quit()
        
        btn_frame = tk.Frame(frame, bg='#2b2b2b')
        btn_frame.pack()
        
        tk.Button(btn_frame, text="Verify", command=confirm,
                 bg='#4caf50', fg='white', font=('Arial', 11, 'bold'),
                 width=12, relief=tk.FLAT, cursor='hand2').pack(side=tk.LEFT, padx=5)
        
        tk.Button(btn_frame, text="Cancel", command=cancel,
                 bg='#666', fg='white', font=('Arial', 11),
                 width=12, relief=tk.FLAT, cursor='hand2').pack(side=tk.LEFT, padx=5)
        
        sudo_dialog.wait_window()
        sudo_dialog.destroy()
        
        return result['password'] if not result['cancelled'] else None
    
    def start_vpn(self):
        """Start VPN server on VPS - ADMIN ONLY with verification"""
        # Check permissions first
        if not self.permissions.get('can_start_stop_vpn', False):
            messagebox.showerror("Access Denied", 
                "❌ You don't have permission to start/stop the VPN server.\n\n"
                "Only ADMIN users can control the VPN server.")
            return
        
        # Verify admin with password
        admin_password = self._prompt_sudo_password()
        if not admin_password:
            return  # User cancelled
        
        # Verify password matches login
        if not self._verify_admin_password(admin_password):
            messagebox.showerror("Verification Failed", 
                "❌ Password verification failed.\n\n"
                "Please enter the correct password for your admin account.")
            return
        
        def do_start():
            try:
                # Ensure API is authenticated
                if not self.api_authenticated:
                    if not self._authenticate_api(self.username, admin_password):
                        self.root.after(0, lambda: messagebox.showerror("Authentication Failed", 
                            "Failed to authenticate with VPS API. Please check your credentials."))
                        return
                
                # Use VPS API to start VPN
                try:
                    resp = self.api_session.post(
                        f"{self.api_base_url}/api/vpn/start",
                        json={'protocol': 'all'},
                        timeout=15
                    )
                    
                    if resp.status_code == 200:
                        data = resp.json()
                        if data.get('success'):
                            results = data.get('results', {})
                            messages = [r.get('message', '') for r in results.values() if r.get('success')]
                            msg = '\n'.join(messages) if messages else 'VPN started successfully'
                            self.root.after(0, lambda: self.show_notification("✨ VPN Started", msg, "success"))
                            self.root.after(0, self.update_status)
                            return
                        else:
                            error_msg = data.get('message', 'Unknown error')
                            self.root.after(0, lambda: messagebox.showerror("Error", f"Failed to start VPN: {error_msg}"))
                            return
                    elif resp.status_code == 401:
                        self.api_authenticated = False
                        self.root.after(0, lambda: messagebox.showerror("Authentication Error", 
                            "Session expired. Please login again."))
                        return
                    elif resp.status_code == 403:
                        self.root.after(0, lambda: messagebox.showerror("Permission Denied", 
                            "You don't have permission to start the VPN server."))
                        return
                    else:
                        self.root.after(0, lambda: messagebox.showerror("Error", 
                            f"Failed to start VPN (HTTP {resp.status_code})"))
                        return
                except requests.exceptions.Timeout:
                    self.root.after(0, lambda: messagebox.showerror("Timeout", 
                        "Request timed out. VPS may be unreachable."))
                    return
                except requests.exceptions.ConnectionError:
                    self.root.after(0, lambda: messagebox.showerror("Connection Error", 
                        "❌ Failed to connect to VPS\n\n"
                        "Please ensure:\n"
                        "• VPS is accessible at phazevpn.com\n"
                        "• Network connection is stable\n"
                        "• Web portal is running"))
                    return
                except Exception as e:
                    self.root.after(0, lambda: messagebox.showerror("Error", f"Failed to start VPN: {e}"))
                    return
                
            except Exception as e:
                self.root.after(0, lambda: messagebox.showerror("Error", f"Failed to start VPN on VPS:\n{e}"))
        
        threading.Thread(target=do_start, daemon=True).start()
        self.status_bar.config(text="🔌 Connecting to VPS and starting VPN server...")
    
    def _verify_admin_password(self, password):
        """Verify admin password matches login credentials"""
        # Try to authenticate with the password
        test_session = requests.Session()
        test_session.verify = False
        try:
            resp = test_session.post(
                f"{self.api_base_url}/api/app/login",
                json={'username': self.username, 'password': password},
                timeout=5
            )
            return resp.status_code == 200
        except:
            # Fallback: if we have stored password, compare
            if hasattr(self, 'password') and self.password:
                return password == self.password
            return False
    
    def show_notification(self, title, message, type="info"):
        """Show a non-blocking notification"""
        notif = tk.Toplevel(self.root)
        notif.title(title)
        notif.geometry("300x100")
        notif.configure(bg='#2b2b2b')
        notif.overrideredirect(True)  # Remove window decorations
        
        # Position at top-right
        notif.update_idletasks()
        x = self.root.winfo_x() + self.root.winfo_width() - 320
        y = self.root.winfo_y() + 50
        notif.geometry(f"300x100+{x}+{y}")
        
        color = '#4caf50' if type == 'success' else '#f44336' if type == 'error' else '#2196F3'
        
        frame = tk.Frame(notif, bg=color, padx=15, pady=15)
        frame.pack(fill=tk.BOTH, expand=True)
        
        tk.Label(frame, text=title, bg=color, fg='white',
                font=('Arial', 12, 'bold')).pack(anchor='w')
        tk.Label(frame, text=message, bg=color, fg='white',
                font=('Arial', 10)).pack(anchor='w', pady=(5, 0))
        
        # Auto-close after 3 seconds
        notif.after(3000, notif.destroy)
    
    def stop_vpn(self):
        """Stop VPN server on VPS - ADMIN ONLY with verification"""
        # Check permissions first
        if not self.permissions.get('can_start_stop_vpn', False):
            messagebox.showerror("Access Denied", 
                "❌ You don't have permission to start/stop the VPN server.\n\n"
                "Only ADMIN users can control the VPN server.")
            return
        
        if not messagebox.askyesno("⚠️ Confirm Stop", 
            "Are you sure you want to stop the VPN server on VPS?\n\n"
            "This will disconnect all active clients."):
            return
        
        # Verify admin with password
        admin_password = self._prompt_sudo_password()
        if not admin_password:
            return
        
        if not self._verify_admin_password(admin_password):
            messagebox.showerror("Verification Failed", 
                "❌ Password verification failed.\n\n"
                "Please enter the correct password for your admin account.")
            return
        
        def do_stop():
            try:
                # Ensure API is authenticated
                if not self.api_authenticated:
                    if not self._authenticate_api(self.username, admin_password):
                        self.root.after(0, lambda: messagebox.showerror("Authentication Failed", 
                            "Failed to authenticate with VPS API."))
                        return
                
                # Use VPS API to stop VPN
                try:
                    resp = self.api_session.post(
                        f"{self.api_base_url}/api/vpn/stop",
                        json={'protocol': 'all'},
                        timeout=15
                    )
                    
                    if resp.status_code == 200:
                        data = resp.json()
                        if data.get('success'):
                            self.root.after(0, lambda: self.show_notification("🛑 VPN Stopped", 
                                "VPS server has been stopped", "info"))
                            self.root.after(0, self.update_status)
                            return
                        else:
                            error_msg = data.get('message', 'Unknown error')
                            self.root.after(0, lambda: messagebox.showerror("Error", f"Failed to stop VPN: {error_msg}"))
                            return
                    elif resp.status_code == 401:
                        self.api_authenticated = False
                        self.root.after(0, lambda: messagebox.showerror("Authentication Error", 
                            "Session expired. Please login again."))
                        return
                    elif resp.status_code == 403:
                        self.root.after(0, lambda: messagebox.showerror("Permission Denied", 
                            "You don't have permission to stop the VPN server."))
                        return
                    else:
                        self.root.after(0, lambda: messagebox.showerror("Error", 
                            f"Failed to stop VPN (HTTP {resp.status_code})"))
                        return
                except requests.exceptions.Timeout:
                    self.root.after(0, lambda: messagebox.showerror("Timeout", 
                        "Request timed out. VPS may be unreachable."))
                    return
                except requests.exceptions.ConnectionError:
                    self.root.after(0, lambda: messagebox.showerror("Connection Error", 
                        "Failed to connect to VPS to stop VPN"))
                    return
                except Exception as e:
                    self.root.after(0, lambda: messagebox.showerror("Error", f"Failed to stop VPN: {e}"))
                    return
                
            except Exception as e:
                self.root.after(0, lambda: messagebox.showerror("Error", f"Failed to stop VPN on VPS:\n{e}"))
        
        threading.Thread(target=do_stop, daemon=True).start()
        self.status_bar.config(text="🔌 Connecting to VPS and stopping VPN server...")
    
    def restart_vpn(self):
        """Restart VPN server on VPS - ADMIN ONLY with verification"""
        # Check permissions first
        if not self.permissions.get('can_start_stop_vpn', False):
            messagebox.showerror("Access Denied", 
                "❌ You don't have permission to restart the VPN server.\n\n"
                "Only ADMIN users can control the VPN server.")
            return
        
        if not messagebox.askyesno("Confirm Restart", 
            "Are you sure you want to restart the VPN server?\n\n"
            "This will temporarily disconnect all active clients."):
            return
        
        # Verify admin with password
        admin_password = self._prompt_sudo_password()
        if not admin_password:
            return
        
        if not self._verify_admin_password(admin_password):
            messagebox.showerror("Verification Failed", 
                "❌ Password verification failed.\n\n"
                "Please enter the correct password for your admin account.")
            return
        
        def do_restart():
            try:
                # Ensure API is authenticated
                if not self.api_authenticated:
                    if not self._authenticate_api(self.username, admin_password):
                        self.root.after(0, lambda: messagebox.showerror("Authentication Failed", 
                            "Failed to authenticate with VPS API."))
                        return
                
                # Use VPS API to restart VPN
                try:
                    resp = self.api_session.post(
                        f"{self.api_base_url}/api/vpn/restart",
                        json={'protocol': 'all'},
                        timeout=20
                    )
                    
                    if resp.status_code == 200:
                        data = resp.json()
                        if data.get('success'):
                            results = data.get('results', {})
                            messages = [r.get('message', '') for r in results.values() if r.get('success')]
                            msg = '\n'.join(messages) if messages else 'VPN restarted successfully'
                            self.root.after(0, lambda: self.show_notification("🔄 VPN Restarted", msg, "success"))
                            self.root.after(0, self.update_status)
                            return
                        else:
                            error_msg = data.get('message', 'Unknown error')
                            self.root.after(0, lambda: messagebox.showerror("Error", f"Failed to restart: {error_msg}"))
                            return
                    elif resp.status_code == 401:
                        self.api_authenticated = False
                        self.root.after(0, lambda: messagebox.showerror("Authentication Error", 
                            "Session expired. Please login again."))
                        return
                    elif resp.status_code == 403:
                        self.root.after(0, lambda: messagebox.showerror("Permission Denied", 
                            "You don't have permission to restart the VPN server."))
                        return
                    else:
                        self.root.after(0, lambda: messagebox.showerror("Error", 
                            f"Failed to restart VPN (HTTP {resp.status_code})"))
                        return
                except requests.exceptions.Timeout:
                    self.root.after(0, lambda: messagebox.showerror("Timeout", 
                        "Request timed out. VPS may be unreachable."))
                    return
                except requests.exceptions.ConnectionError:
                    self.root.after(0, lambda: messagebox.showerror("Connection Error", 
                        "Failed to connect to VPS to restart VPN"))
                    return
                except Exception as e:
                    self.root.after(0, lambda: messagebox.showerror("Error", f"Failed to restart VPN: {e}"))
                    return
                
            except Exception as e:
                self.root.after(0, lambda: messagebox.showerror("Error", f"Failed to restart VPN on VPS:\n{e}"))
        
        threading.Thread(target=do_restart, daemon=True).start()
        self.status_bar.config(text="🔄 Restarting VPN server on VPS...")
    
    def start_auto_refresh(self):
        def refresh():
            self.update_status()
            self.root.after(5000, refresh)  # Refresh every 5 seconds
        
        self.root.after(5000, refresh)
    
    def show_context_menu(self, event):
        item = self.tree.selection()[0] if self.tree.selection() else None
        if item:
            self.context_menu.post(event.x_root, event.y_root)
    
    def get_selected_client(self):
        selection = self.tree.selection()
        if not selection:
            messagebox.showwarning("No Selection", "Please select a client first")
            return None
        
        item = selection[0]
        values = self.tree.item(item, 'values')
        client_name = values[0]
        
        # Find full client data
        for conn in self.connections_data:
            if conn.get('name') == client_name:
                return conn
        return None
    
    def view_client_details(self):
        client = self.get_selected_client()
        if not client:
            return
        
        # Create details window
        details = tk.Toplevel(self.root)
        details.title(f"Client Details: {client.get('name', 'Unknown')}")
        details.geometry("500x400")
        details.configure(bg='#2b2b2b')
        
        frame = tk.Frame(details, bg='#2b2b2b', padx=20, pady=20)
        frame.pack(fill=tk.BOTH, expand=True)
        
        tk.Label(frame, text=f"Client: {client.get('name', 'Unknown')}", 
                font=('Arial', 16, 'bold'), bg='#2b2b2b', fg='#ffffff').pack(anchor='w', pady=(0, 20))
        
        info_text = f"""
Real IP Address: {client.get('real_ip', 'N/A')}
VPN IP Address: {client.get('virtual_ip', 'N/A')}
Bytes Received: {self.format_bytes(client.get('bytes_rx', 0))}
Bytes Sent: {self.format_bytes(client.get('bytes_tx', 0))}
Total Data: {self.format_bytes(client.get('bytes_rx', 0) + client.get('bytes_tx', 0))}
Connected Since: {client.get('connected_since', 'Unknown')}
        """
        
        tk.Label(frame, text=info_text.strip(), 
                font=('Courier', 11), bg='#2b2b2b', fg='#aaaaaa',
                justify=tk.LEFT).pack(anchor='w', pady=(0, 20))
        
        # Action buttons
        btn_frame = tk.Frame(frame, bg='#2b2b2b')
        btn_frame.pack(fill=tk.X)
        
        tk.Button(btn_frame, text="🔌 Disconnect", 
                 command=lambda: self.disconnect_client_by_name(client.get('name')),
                 bg='#f44336', fg='white', font=('Arial', 10, 'bold'),
                 relief=tk.FLAT, cursor='hand2', padx=10, pady=5).pack(side=tk.LEFT, padx=5)
        
        tk.Button(btn_frame, text="📝 Edit Config", 
                 command=lambda: self.edit_client_config_by_name(client.get('name')),
                 bg='#ff9800', fg='white', font=('Arial', 10, 'bold'),
                 relief=tk.FLAT, cursor='hand2', padx=10, pady=5).pack(side=tk.LEFT, padx=5)
        
        tk.Button(btn_frame, text="Close", 
                 command=details.destroy,
                 bg='#666', fg='white', font=('Arial', 10),
                 relief=tk.FLAT, cursor='hand2', padx=10, pady=5).pack(side=tk.RIGHT)
    
    def disconnect_client(self):
        if not self.permissions.get('can_disconnect_clients', False):
            messagebox.showwarning("Permission Denied", "You don't have permission to disconnect clients")
            return
        
        client = self.get_selected_client()
        if not client:
            return
        
        if messagebox.askyesno("Disconnect Client", 
                              f"Disconnect {client.get('name')} from the VPN?"):
            self.disconnect_client_by_name(client.get('name'))
    
    def disconnect_client_by_name(self, client_name):
        try:
            # Use management interface to disconnect
            result = subprocess.run(['sudo', 'kill', '-SIGTERM', 
                                   f"$(pgrep -f 'openvpn.*{client_name}')"],
                                  shell=True, capture_output=True, text=True)
            messagebox.showinfo("Disconnected", f"Client {client_name} has been disconnected")
            self.update_status()
        except Exception as e:
            messagebox.showerror("Error", f"Failed to disconnect client: {e}")
    
    def edit_client_config(self):
        client = self.get_selected_client()
        if not client:
            return
        self.edit_client_config_by_name(client.get('name'))
    
    def edit_client_config_by_name(self, client_name):
        config_file = VPN_DIR / 'client-configs' / f'{client_name}.ovpn'
        if not config_file.exists():
            messagebox.showwarning("Config Not Found", 
                                 f"Config file for {client_name} not found")
            return
        
        # Open config editor
        editor = tk.Toplevel(self.root)
        editor.title(f"Edit Config: {client_name}")
        editor.geometry("700x600")
        editor.configure(bg='#2b2b2b')
        
        frame = tk.Frame(editor, bg='#2b2b2b', padx=15, pady=15)
        frame.pack(fill=tk.BOTH, expand=True)
        
        tk.Label(frame, text=f"Editing: {client_name}.ovpn", 
                font=('Arial', 12, 'bold'), bg='#2b2b2b', fg='#ffffff').pack(anchor='w', pady=(0, 10))
        
        text_area = scrolledtext.ScrolledText(frame, bg='#1a1a1a', fg='#00ff00',
                                             font=('Courier', 10), wrap=tk.WORD)
        text_area.pack(fill=tk.BOTH, expand=True, pady=(0, 10))
        
        # Load config
        try:
            with open(config_file) as f:
                text_area.insert(1.0, f.read())
        except Exception as e:
            messagebox.showerror("Error", f"Failed to load config: {e}")
        
        def save_config():
            try:
                with open(config_file, 'w') as f:
                    f.write(text_area.get(1.0, tk.END))
                messagebox.showinfo("Saved", "Config file saved successfully!")
                editor.destroy()
            except Exception as e:
                messagebox.showerror("Error", f"Failed to save: {e}")
        
        btn_frame = tk.Frame(frame, bg='#2b2b2b')
        btn_frame.pack(fill=tk.X)
        
        tk.Button(btn_frame, text="💾 Save", command=save_config,
                 bg='#4caf50', fg='white', font=('Arial', 10, 'bold'),
                 relief=tk.FLAT, cursor='hand2', padx=15, pady=5).pack(side=tk.LEFT)
        
        tk.Button(btn_frame, text="Cancel", command=editor.destroy,
                 bg='#666', fg='white', font=('Arial', 10),
                 relief=tk.FLAT, cursor='hand2', padx=15, pady=5).pack(side=tk.RIGHT)
    
    def revoke_client(self):
        if not self.permissions.get('can_revoke_clients', False):
            messagebox.showwarning("Permission Denied", "You don't have permission to revoke clients")
            return
        
        client = self.get_selected_client()
        if not client:
            return
        
        if messagebox.askyesno("Revoke Access", 
                              f"Revoke VPN access for {client.get('name')}?\n\n"
                              "This will disconnect them and remove their certificate."):
            try:
                # Disconnect first
                self.disconnect_client_by_name(client.get('name'))
                
                # Remove certificate files
                cert_dir = VPN_DIR / 'certs'
                config_dir = VPN_DIR / 'client-configs'
                
                for file in [cert_dir / f"{client.get('name')}.crt",
                            cert_dir / f"{client.get('name')}.key",
                            config_dir / f"{client.get('name')}.ovpn"]:
                    if file.exists():
                        file.unlink()
                
                messagebox.showinfo("Revoked", f"Access revoked for {client.get('name')}")
                self.update_status()
            except Exception as e:
                messagebox.showerror("Error", f"Failed to revoke access: {e}")
    
    def add_client(self):
        if not self.permissions.get('can_add_clients', False):
            messagebox.showwarning("Permission Denied", "You don't have permission to add clients")
            return
        
        dialog = tk.Toplevel(self.root)
        dialog.title("Add New Client")
        dialog.geometry("400x200")
        dialog.configure(bg='#2b2b2b')
        dialog.resizable(False, False)
        
        frame = tk.Frame(dialog, bg='#2b2b2b', padx=30, pady=30)
        frame.pack(fill=tk.BOTH, expand=True)
        
        tk.Label(frame, text="Client Name:", bg='#2b2b2b', fg='#ffffff',
                font=('Arial', 11)).pack(anchor='w', pady=(0, 5))
        
        name_entry = tk.Entry(frame, font=('Arial', 12), width=30)
        name_entry.pack(pady=(0, 20))
        name_entry.focus()
        
        def create_client():
            name = name_entry.get().strip()
            if not name:
                messagebox.showerror("Error", "Client name is required")
                return
            
            # Show password dialog
            password_dialog = tk.Toplevel(dialog)
            password_dialog.title("Sudo Password Required")
            password_dialog.geometry("400x200")
            password_dialog.configure(bg='#2b2b2b')
            password_dialog.resizable(False, False)
            password_dialog.transient(dialog)
            password_dialog.grab_set()
            
            # Center the password dialog
            password_dialog.update_idletasks()
            x = password_dialog.winfo_x() + (password_dialog.winfo_width() // 2) - 200
            y = password_dialog.winfo_y() + (password_dialog.winfo_height() // 2) - 100
            password_dialog.geometry(f"400x200+{x}+{y}")
            
            pwd_frame = tk.Frame(password_dialog, bg='#2b2b2b', padx=30, pady=30)
            pwd_frame.pack(fill=tk.BOTH, expand=True)
            
            tk.Label(pwd_frame, text="Sudo Password Required", 
                    bg='#2b2b2b', fg='#ffffff',
                    font=('Arial', 14, 'bold')).pack(pady=(0, 15))
            
            tk.Label(pwd_frame, text="Enter your sudo password to create client certificates:", 
                    bg='#2b2b2b', fg='#aaaaaa',
                    font=('Arial', 10)).pack(pady=(0, 10))
            
            sudo_password_entry = tk.Entry(pwd_frame, font=('Arial', 12), 
                                          show='*', width=30)
            sudo_password_entry.pack(pady=(0, 20))
            sudo_password_entry.focus()
            
            pwd_error = tk.Label(pwd_frame, text="", 
                               bg='#2b2b2b', fg='#ff4444',
                               font=('Arial', 9))
            pwd_error.pack(pady=(0, 10))
            
            def do_create():
                sudo_password = sudo_password_entry.get()
                if not sudo_password:
                    pwd_error.config(text="Password is required")
                    return
                
                password_dialog.destroy()
                
                # Show progress
                progress = tk.Toplevel(dialog)
                progress.title("Creating Client")
                progress.geometry("300x100")
                progress.configure(bg='#2b2b2b')
                progress.transient(dialog)
                
                prog_frame = tk.Frame(progress, bg='#2b2b2b', padx=20, pady=20)
                prog_frame.pack(fill=tk.BOTH, expand=True)
                
                tk.Label(prog_frame, text="Creating client... Please wait.", 
                        bg='#2b2b2b', fg='#ffffff',
                        font=('Arial', 11)).pack()
                
                progress.update()
                
                try:
                    # First, try to create client on VPS via API (if authenticated)
                    vps_created = False
                    if self.api_authenticated:
                        try:
                            # Verify admin password for API
                            if not self._verify_admin_password(sudo_password):
                                raise Exception("Password verification failed")
                            
                            resp = self.api_session.post(
                                f"{self.api_base_url}/api/clients",
                                json={'name': name},
                                timeout=15
                            )
                            
                            if resp.status_code == 200:
                                data = resp.json()
                                if data.get('success'):
                                    vps_created = True
                                    progress.destroy()
                                    download_url = f"{self.api_base_url}/download/{name}"
                                    messagebox.showinfo("Success", 
                                                      f"✅ Client '{name}' created on VPS!\n\n"
                                                      f"📥 Download link:\n{download_url}\n\n"
                                                      f"🔗 Share this URL with the client to download their config.")
                                    dialog.destroy()
                                    self.update_status()
                                    return
                        except Exception as e:
                            # If VPS API fails, fall back to local creation
                            print(f"VPS API creation failed: {e}, falling back to local")
                    
                    # Fallback: Create client locally (for offline mode or if VPS unavailable)
                    if not vps_created:
                        # Use sudo with -S to read password from stdin
                        process = subprocess.Popen(
                            ['sudo', '-S', 'python3', str(VPN_DIR / 'vpn-manager.py'), 'add-client', name],
                            stdin=subprocess.PIPE,
                            stdout=subprocess.PIPE,
                            stderr=subprocess.PIPE,
                            text=True
                        )
                        
                        stdout, stderr = process.communicate(input=sudo_password + '\n', timeout=30)
                        
                        # Check if file was actually created
                        config_file = VPN_DIR / 'client-configs' / f'{name}.ovpn'
                        
                        progress.destroy()
                        
                        if process.returncode == 0 and config_file.exists():
                            download_url = f"{self.api_base_url}/download/{name}"
                            messagebox.showinfo("Success", 
                                              f"✅ Client '{name}' created locally!\n\n"
                                              f"📁 Config file: client-configs/{name}.ovpn\n\n"
                                              f"📥 Download link:\n{download_url}\n\n"
                                              f"⚠️  Note: Sync to VPS on next connection")
                            dialog.destroy()
                            self.update_status()
                        elif process.returncode != 0:
                            error_msg = stderr if stderr else stdout
                            if "password" in error_msg.lower() or "incorrect" in error_msg.lower():
                                messagebox.showerror("Authentication Failed", 
                                                   "Sudo password was incorrect. Please try again.")
                            else:
                                messagebox.showerror("Error", f"Failed to create client:\n{error_msg}")
                        elif not config_file.exists():
                            messagebox.showerror("Error", 
                                               f"Command completed but config file not found!\n\n"
                                               f"Expected: {config_file}\n\n"
                                               f"Please check the error messages above.")
                except subprocess.TimeoutExpired:
                    progress.destroy()
                    messagebox.showerror("Error", "Operation timed out. Please try again.")
                except FileNotFoundError:
                    progress.destroy()
                    messagebox.showerror("Error", f"vpn-manager.py not found at:\n{VPN_DIR / 'vpn-manager.py'}")
                except Exception as e:
                    progress.destroy()
                    messagebox.showerror("Error", f"Failed to create client: {e}")
            
            btn_frame = tk.Frame(pwd_frame, bg='#2b2b2b')
            btn_frame.pack(fill=tk.X)
            
            tk.Button(btn_frame, text="Create Client", 
                     command=do_create,
                     bg='#4caf50', fg='white',
                     font=('Arial', 11, 'bold'),
                     relief=tk.FLAT, cursor='hand2',
                     padx=20, pady=8).pack(side=tk.LEFT, padx=5)
            
            tk.Button(btn_frame, text="Cancel", 
                     command=password_dialog.destroy,
                     bg='#666', fg='white',
                     font=('Arial', 11),
                     relief=tk.FLAT, cursor='hand2',
                     padx=20, pady=8).pack(side=tk.RIGHT, padx=5)
            
            sudo_password_entry.bind('<Return>', lambda e: do_create())
        
        btn_frame = tk.Frame(frame, bg='#2b2b2b')
        btn_frame.pack(fill=tk.X)
        
        tk.Button(btn_frame, text="Create", command=create_client,
                 bg='#4caf50', fg='white', font=('Arial', 11, 'bold'),
                 relief=tk.FLAT, cursor='hand2', padx=20, pady=8).pack(side=tk.LEFT)
        
        tk.Button(btn_frame, text="Cancel", command=dialog.destroy,
                 bg='#666', fg='white', font=('Arial', 11),
                 relief=tk.FLAT, cursor='hand2', padx=20, pady=8).pack(side=tk.RIGHT)
        
        name_entry.bind('<Return>', lambda e: create_client())
    
    def view_all_clients(self):
        config_dir = VPN_DIR / 'client-configs'
        clients = []
        if config_dir.exists():
            clients = [f.stem for f in config_dir.glob('*.ovpn')]
        
        window = tk.Toplevel(self.root)
        window.title("All Clients")
        window.geometry("500x400")
        window.configure(bg='#2b2b2b')
        
        frame = tk.Frame(window, bg='#2b2b2b', padx=20, pady=20)
        frame.pack(fill=tk.BOTH, expand=True)
        
        tk.Label(frame, text=f"Total Clients: {len(clients)}", 
                font=('Arial', 14, 'bold'), bg='#2b2b2b', fg='#ffffff').pack(anchor='w', pady=(0, 15))
        
        listbox = tk.Listbox(frame, bg='#1a1a1a', fg='#ffffff',
                           font=('Courier', 11), selectbackground='#667eea')
        listbox.pack(fill=tk.BOTH, expand=True, pady=(0, 10))
        
        for client in sorted(clients):
            listbox.insert(tk.END, client)
        
        def open_client():
            selection = listbox.curselection()
            if selection:
                client_name = listbox.get(selection[0])
                self.edit_client_config_by_name(client_name)
                window.destroy()
        
        def download_client():
            selection = listbox.curselection()
            if selection:
                client_name = listbox.get(selection[0])
                self.export_config_file(client_name)
        
        btn_frame = tk.Frame(frame, bg='#2b2b2b')
        btn_frame.pack(fill=tk.X)
        
        tk.Button(btn_frame, text="📥 Download Config", command=download_client,
                 bg='#4caf50', fg='white', font=('Arial', 10, 'bold'),
                 relief=tk.FLAT, cursor='hand2', padx=15, pady=5).pack(side=tk.LEFT, padx=5)
        
        tk.Button(btn_frame, text="⚙️ Open Config", command=open_client,
                 bg='#2196F3', fg='white', font=('Arial', 10, 'bold'),
                 relief=tk.FLAT, cursor='hand2', padx=15, pady=5).pack(side=tk.LEFT, padx=5)
        
        tk.Button(btn_frame, text="Close", command=window.destroy,
                 bg='#666', fg='white', font=('Arial', 10),
                 relief=tk.FLAT, cursor='hand2', padx=15, pady=5).pack(side=tk.RIGHT)
    
    def edit_server_config(self):
        if not self.permissions.get('can_edit_server_config', False):
            messagebox.showwarning("Permission Denied", "You don't have permission to edit server configuration")
            return
        
        config_file = VPN_DIR / 'config' / 'server.conf'
        if not config_file.exists():
            messagebox.showerror("Error", "Server config file not found")
            return
        
        editor = tk.Toplevel(self.root)
        editor.title("Edit Server Configuration")
        editor.geometry("800x700")
        editor.configure(bg='#2b2b2b')
        
        frame = tk.Frame(editor, bg='#2b2b2b', padx=15, pady=15)
        frame.pack(fill=tk.BOTH, expand=True)
        
        tk.Label(frame, text="⚠️ Warning: Restart VPN after changes!", 
                font=('Arial', 11, 'bold'), bg='#2b2b2b', fg='#ff9800').pack(anchor='w', pady=(0, 10))
        
        text_area = scrolledtext.ScrolledText(frame, bg='#1a1a1a', fg='#00ff00',
                                             font=('Courier', 10), wrap=tk.NONE)
        text_area.pack(fill=tk.BOTH, expand=True, pady=(0, 10))
        
        try:
            with open(config_file) as f:
                text_area.insert(1.0, f.read())
        except Exception as e:
            messagebox.showerror("Error", f"Failed to load config: {e}")
        
        def save_config():
            if messagebox.askyesno("Confirm", "Save changes? VPN will need to be restarted."):
                try:
                    config_content = text_area.get(1.0, tk.END)
                    
                    # Try to save directly first
                    try:
                        with open(config_file, 'w') as f:
                            f.write(config_content)
                        messagebox.showinfo("Saved", "Config saved! Restart VPN to apply changes.")
                        editor.destroy()
                        return
                    except PermissionError:
                        # Need elevated privileges - use pkexec or save to temp then copy
                        import tempfile
                        temp_file = tempfile.NamedTemporaryFile(mode='w', delete=False, suffix='.conf')
                        temp_file.write(config_content)
                        temp_file.close()
                        
                        # Try pkexec first (graphical sudo)
                        if shutil.which('pkexec'):
                            result = subprocess.run(
                                ['pkexec', 'cp', temp_file.name, str(config_file)],
                                capture_output=True, text=True, timeout=10
                            )
                        else:
                            # Fallback: try with tee and sudo
                            result = subprocess.run(
                                ['sudo', 'tee', str(config_file)],
                                input=config_content,
                                capture_output=True, text=True, timeout=10
                            )
                        
                        # Clean up temp file
                        os.unlink(temp_file.name)
                        
                        if result.returncode == 0:
                            messagebox.showinfo("Saved", "Config saved! Restart VPN to apply changes.")
                            editor.destroy()
                        else:
                            error_msg = result.stderr if result.stderr else "Permission denied"
                            messagebox.showerror("Error", f"Failed to save: {error_msg}")
                except Exception as e:
                    messagebox.showerror("Error", f"Failed to save: {e}")
        
        btn_frame = tk.Frame(frame, bg='#2b2b2b')
        btn_frame.pack(fill=tk.X)
        
        tk.Button(btn_frame, text="💾 Save", command=save_config,
                 bg='#4caf50', fg='white', font=('Arial', 10, 'bold'),
                 relief=tk.FLAT, cursor='hand2', padx=15, pady=5).pack(side=tk.LEFT, padx=5)
        
        tk.Button(btn_frame, text="🔄 Save & Restart", 
                 command=lambda: [save_config(), self.restart_vpn()],
                 bg='#ff9800', fg='white', font=('Arial', 10, 'bold'),
                 relief=tk.FLAT, cursor='hand2', padx=15, pady=5).pack(side=tk.LEFT, padx=5)
        
        tk.Button(btn_frame, text="Cancel", command=editor.destroy,
                 bg='#666', fg='white', font=('Arial', 10),
                 relief=tk.FLAT, cursor='hand2', padx=15, pady=5).pack(side=tk.RIGHT)
    
    def show_statistics(self):
        stats = tk.Toplevel(self.root)
        stats.title("VPN Statistics & Analytics")
        stats.geometry("700x600")
        stats.configure(bg='#2b2b2b')
        
        # Notebook for tabs
        notebook = ttk.Notebook(stats)
        notebook.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)
        
        # Overview tab
        overview_frame = tk.Frame(notebook, bg='#2b2b2b', padx=20, pady=20)
        notebook.add(overview_frame, text="📊 Overview")
        
        connections = self.get_connections()
        total_rx = sum(c.get('bytes_rx', 0) for c in connections)
        total_tx = sum(c.get('bytes_tx', 0) for c in connections)
        total_data = total_rx + total_tx
        
        # Calculate averages
        avg_data_per_client = total_data / len(connections) if connections else 0
        
        stats_text = f"""
╔═══════════════════════════════════════════════════════╗
║           VPN SERVER STATISTICS                       ║
╚═══════════════════════════════════════════════════════╝

Server Status: {'🟢 RUNNING' if self.is_vpn_running() else '🔴 STOPPED'}
Active Connections: {len(connections)}

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

📥 DATA TRANSFERRED:
  • Downloaded: {self.format_bytes(total_rx)}
  • Uploaded: {self.format_bytes(total_tx)}
  • Total: {self.format_bytes(total_data)}
  • Average per client: {self.format_bytes(avg_data_per_client)}

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

👥 CLIENT BREAKDOWN:
"""
        
        # Sort by data usage
        sorted_clients = sorted(connections, key=lambda x: x.get('bytes_rx', 0) + x.get('bytes_tx', 0), reverse=True)
        for i, conn in enumerate(sorted_clients[:10], 1):  # Top 10
            client_data = conn.get('bytes_rx', 0) + conn.get('bytes_tx', 0)
            percentage = (client_data / total_data * 100) if total_data > 0 else 0
            stats_text += f"  {i}. {conn.get('name', 'Unknown'):<20} {self.format_bytes(client_data):>12} ({percentage:.1f}%)\n"
        
        # Connection history graph (text-based)
        stats_text += "\n━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n"
        stats_text += "\n📈 CONNECTION HISTORY (Last 10 updates):\n"
        
        if len(self.connection_history) > 1:
            recent = self.connection_history[-10:]
            max_count = max(h['count'] for h in recent) if recent else 1
            for h in recent:
                bar_length = int((h['count'] / max_count) * 30) if max_count > 0 else 0
                bar = '█' * bar_length
                stats_text += f"  {bar} {h['count']} connections\n"
        
        text_widget = scrolledtext.ScrolledText(overview_frame, bg='#1a1a1a', fg='#00ff00',
                                               font=('Courier', 10), wrap=tk.NONE)
        text_widget.pack(fill=tk.BOTH, expand=True)
        text_widget.insert(1.0, stats_text)
        text_widget.config(state=tk.DISABLED)
        
        # Performance tab
        perf_frame = tk.Frame(notebook, bg='#2b2b2b', padx=20, pady=20)
        notebook.add(perf_frame, text="⚡ Performance")
        
        perf_text = f"""
╔═══════════════════════════════════════════════════════╗
║           SYSTEM PERFORMANCE                           ║
╚═══════════════════════════════════════════════════════╝

Server Performance Metrics:
"""
        
        try:
            # Get system info
            import psutil
            cpu_percent = psutil.cpu_percent(interval=0.1)
            memory = psutil.virtual_memory()
            disk = psutil.disk_usage('/')
            
            perf_text += f"""
CPU Usage: {cpu_percent:.1f}%
Memory Usage: {memory.percent:.1f}% ({self.format_bytes(memory.used)} / {self.format_bytes(memory.total)})
Disk Usage: {disk.percent:.1f}% ({self.format_bytes(disk.used)} / {self.format_bytes(disk.total)})

Network Interfaces:
"""
            for interface, addrs in psutil.net_if_addrs().items():
                if interface.startswith('tun') or interface.startswith('eth') or interface.startswith('enp'):
                    stats = psutil.net_io_counters(pernic=True).get(interface)
                    if stats:
                        perf_text += f"  • {interface}: RX {self.format_bytes(stats.bytes_recv)}, TX {self.format_bytes(stats.bytes_sent)}\n"
        except ImportError:
            perf_text += "\n(Install 'psutil' for detailed system metrics: pip3 install psutil)\n"
        except Exception as e:
            perf_text += f"\nError getting metrics: {e}\n"
        
        perf_text_widget = scrolledtext.ScrolledText(perf_frame, bg='#1a1a1a', fg='#00ff00',
                                                    font=('Courier', 10), wrap=tk.NONE)
        perf_text_widget.pack(fill=tk.BOTH, expand=True)
        perf_text_widget.insert(1.0, perf_text)
        perf_text_widget.config(state=tk.DISABLED)
        
        # Close button
        btn_frame = tk.Frame(stats, bg='#2b2b2b')
        btn_frame.pack(fill=tk.X, padx=10, pady=10)
        
        tk.Button(btn_frame, text="🔄 Refresh", command=lambda: [stats.destroy(), self.show_statistics()],
                 bg='#667eea', fg='white', font=('Arial', 10, 'bold'),
                 relief=tk.FLAT, cursor='hand2', padx=15, pady=5).pack(side=tk.LEFT, padx=5)
        
        tk.Button(btn_frame, text="Close", command=stats.destroy,
                 bg='#666', fg='white', font=('Arial', 10),
                 relief=tk.FLAT, cursor='hand2', padx=20, pady=5).pack(side=tk.RIGHT)
    
    def backup_config(self):
        if not self.permissions.get('can_backup', False):
            messagebox.showwarning("Permission Denied", "You don't have permission to create backups")
            return
        
        from datetime import datetime
        backup_dir = VPN_DIR / 'backups'
        backup_dir.mkdir(exist_ok=True)
        
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        backup_path = backup_dir / f"backup_{timestamp}"
        backup_path.mkdir(exist_ok=True)
        
        try:
            # Backup configs
            import shutil
            config_dir = VPN_DIR / 'config'
            if config_dir.exists():
                shutil.copytree(config_dir, backup_path / 'config', dirs_exist_ok=True)
            
            # Backup client configs
            client_dir = VPN_DIR / 'client-configs'
            if client_dir.exists():
                shutil.copytree(client_dir, backup_path / 'client-configs', dirs_exist_ok=True)
            
            # Backup certs (keys excluded for security)
            certs_dir = VPN_DIR / 'certs'
            if certs_dir.exists():
                (backup_path / 'certs').mkdir(exist_ok=True)
                for file in certs_dir.glob('*.crt'):
                    shutil.copy2(file, backup_path / 'certs')
                for file in certs_dir.glob('*.pem'):
                    shutil.copy2(file, backup_path / 'certs')
            
            messagebox.showinfo("Backup Complete", 
                              f"Backup created successfully!\n\n"
                              f"Location: backups/backup_{timestamp}\n\n"
                              f"Note: Private keys were NOT backed up for security.")
        except Exception as e:
            messagebox.showerror("Backup Failed", f"Failed to create backup: {e}")
    
    def export_client_config(self):
        client = self.get_selected_client()
        if not client:
            # Show all clients to choose from
            config_dir = VPN_DIR / 'client-configs'
            clients = [f.stem for f in config_dir.glob('*.ovpn')] if config_dir.exists() else []
            
            if not clients:
                messagebox.showwarning("No Clients", "No client configs found")
                return
            
            # Quick selection dialog
            sel = tk.Toplevel(self.root)
            sel.title("Select Client to Export")
            sel.geometry("300x200")
            sel.configure(bg='#2b2b2b')
            
            frame = tk.Frame(sel, bg='#2b2b2b', padx=20, pady=20)
            frame.pack(fill=tk.BOTH, expand=True)
            
            tk.Label(frame, text="Select client:", bg='#2b2b2b', fg='#ffffff',
                    font=('Arial', 11)).pack(pady=(0, 10))
            
            listbox = tk.Listbox(frame, bg='#1a1a1a', fg='#ffffff', height=6)
            listbox.pack(fill=tk.BOTH, expand=True, pady=(0, 10))
            
            for client_name in sorted(clients):
                listbox.insert(tk.END, client_name)
            
            def export_selected():
                selection = listbox.curselection()
                if selection:
                    client_name = listbox.get(selection[0])
                    sel.destroy()
                    self.export_config_file(client_name)
            
            tk.Button(frame, text="Export", command=export_selected,
                     bg='#4caf50', fg='white', font=('Arial', 10, 'bold'),
                     relief=tk.FLAT, cursor='hand2', padx=15, pady=5).pack()
            return
        
        self.export_config_file(client.get('name'))
    
    def export_config_file(self, client_name):
        config_file = VPN_DIR / 'client-configs' / f'{client_name}.ovpn'
        if not config_file.exists():
            messagebox.showerror("Error", f"Config file for {client_name} not found")
            return
        
        # Ask where to save
        filename = filedialog.asksaveasfilename(
            defaultextension=".ovpn",
            filetypes=[("OpenVPN Config", "*.ovpn"), ("All Files", "*.*")],
            initialfile=f"{client_name}.ovpn"
        )
        
        if filename:
            try:
                shutil.copy2(config_file, filename)
                messagebox.showinfo("Exported", f"Client config exported to:\n{filename}")
            except Exception as e:
                messagebox.showerror("Error", f"Failed to export: {e}")
    
    def start_download_server(self):
        """Show download server information - Uses VPS web portal"""
        # Use VPS web portal for downloads (unified system)
        download_base_url = self.api_base_url
        
        # Create download info window
        info_window = tk.Toplevel(self.root)
        info_window.title("Client Download Server")
        info_window.geometry("600x500")
        info_window.configure(bg='#2b2b2b')
        info_window.resizable(False, False)
        
        # Center window
        info_window.update_idletasks()
        x = (info_window.winfo_screenwidth() // 2) - 300
        y = (info_window.winfo_screenheight() // 2) - 250
        info_window.geometry(f"600x500+{x}+{y}")
        
        frame = tk.Frame(info_window, bg='#2b2b2b', padx=30, pady=30)
        frame.pack(fill=tk.BOTH, expand=True)
        
        tk.Label(frame, text="🌐 Client Download Server", 
                font=('Arial', 18, 'bold'), bg='#2b2b2b', fg='#ffffff').pack(pady=(0, 20))
        
        # Download URL
        url_frame = tk.Frame(frame, bg='#1a1a1a', padx=15, pady=15)
        url_frame.pack(fill=tk.X, pady=(0, 20))
        
        tk.Label(url_frame, text="Download URL:", 
                bg='#1a1a1a', fg='#aaaaaa',
                font=('Arial', 11)).pack(anchor='w')
        
        url_text = f"{download_base_url}/download"
        url_label = tk.Label(url_frame, text=url_text, 
                           bg='#1a1a1a', fg='#4caf50',
                           font=('Courier', 12, 'bold'),
                           cursor='hand2')
        url_label.pack(anchor='w', pady=(5, 0))
        url_label.bind('<Button-1>', lambda e: self._copy_to_clipboard(url_text))
        
        # Instructions
        instructions = f"""
✅ Download server is integrated with VPS web portal!

📱 How clients download configs:

1. Visit: {download_base_url}/download
2. Enter their client name
3. Click "Download Config"
4. Import the .ovpn file into their VPN client

🔗 Direct download links:
   • Main page: {download_base_url}/download
   • Client list: {download_base_url}/dashboard

💡 Benefits of unified system:
   • No separate server to manage
   • All configs synced with VPS
   • Secure authentication
   • Works from anywhere
        """
        
        tk.Label(frame, text=instructions.strip(), 
                bg='#2b2b2b', fg='#ffffff',
                font=('Arial', 10),
                justify=tk.LEFT).pack(anchor='w', pady=(0, 20))
        
        # Get available clients
        try:
            if self.api_authenticated:
                resp = self.api_session.get(f"{self.api_base_url}/api/clients", timeout=5)
                if resp.status_code == 200:
                    data = resp.json()
                    clients = data.get('clients', [])
                    if clients:
                        clients_text = "Available clients:\n" + "\n".join([f"  • {c.get('name', 'Unknown')}" for c in clients[:10]])
                        if len(clients) > 10:
                            clients_text += f"\n  ... and {len(clients) - 10} more"
                        tk.Label(frame, text=clients_text, 
                                bg='#2b2b2b', fg='#aaaaaa',
                                font=('Courier', 9),
                                justify=tk.LEFT).pack(anchor='w', pady=(0, 20))
        except:
            pass
        
        # Buttons
        btn_frame = tk.Frame(frame, bg='#2b2b2b')
        btn_frame.pack(fill=tk.X)
        
        tk.Button(btn_frame, text="📋 Copy URL", 
                 command=lambda: self._copy_to_clipboard(url_text),
                 bg='#2196F3', fg='white',
                 font=('Arial', 11, 'bold'),
                 width=15, relief=tk.FLAT, cursor='hand2').pack(side=tk.LEFT, padx=5)
        
        tk.Button(btn_frame, text="🌐 Open in Browser", 
                 command=lambda: self._open_url(url_text),
                 bg='#4caf50', fg='white',
                 font=('Arial', 11, 'bold'),
                 width=18, relief=tk.FLAT, cursor='hand2').pack(side=tk.LEFT, padx=5)
        
        tk.Button(btn_frame, text="Close", 
                 command=info_window.destroy,
                 bg='#666', fg='white',
                 font=('Arial', 11),
                 width=12, relief=tk.FLAT, cursor='hand2').pack(side=tk.RIGHT, padx=5)
    
    def _copy_to_clipboard(self, text):
        """Copy text to clipboard"""
        self.root.clipboard_clear()
        self.root.clipboard_append(text)
        messagebox.showinfo("Copied", f"URL copied to clipboard:\n{text}")
    
    def _open_url(self, url):
        """Open URL in default browser"""
        import webbrowser
        try:
            webbrowser.open(url)
        except Exception as e:
            messagebox.showerror("Error", f"Failed to open browser: {e}")
    
    def open_support_portal(self):
        """Open support portal window for moderators"""
        if self.role != 'moderator':
            messagebox.showwarning("Access Denied", "Only moderators can access the support portal")
            return
        
        SupportPortalWindow(self.root, self.username, self.get_connections())
    
    def client_settings(self):
        client = self.get_selected_client()
        if not client:
            messagebox.showinfo("Client Settings", 
                              "Select a client from the connections list first,\n"
                              "or use 'View All Clients' to select one.")
            return
        
        settings = tk.Toplevel(self.root)
        settings.title(f"Client Settings: {client.get('name')}")
        settings.geometry("500x400")
        settings.configure(bg='#2b2b2b')
        
        frame = tk.Frame(settings, bg='#2b2b2b', padx=20, pady=20)
        frame.pack(fill=tk.BOTH, expand=True)
        
        tk.Label(frame, text=f"Settings for: {client.get('name')}", 
                font=('Arial', 14, 'bold'), bg='#2b2b2b', fg='#ffffff').pack(anchor='w', pady=(0, 20))
        
        # Bandwidth limit
        tk.Label(frame, text="Bandwidth Limit (Mbps):", 
                bg='#2b2b2b', fg='#ffffff', font=('Arial', 11)).pack(anchor='w', pady=(0, 5))
        bw_entry = tk.Entry(frame, font=('Arial', 12), width=20)
        bw_entry.pack(anchor='w', pady=(0, 15))
        bw_entry.insert(0, "Unlimited")
        
        # Connection time limit
        tk.Label(frame, text="Max Connection Time (hours):", 
                bg='#2b2b2b', fg='#ffffff', font=('Arial', 11)).pack(anchor='w', pady=(0, 5))
        time_entry = tk.Entry(frame, font=('Arial', 12), width=20)
        time_entry.pack(anchor='w', pady=(0, 15))
        time_entry.insert(0, "Unlimited")
        
        # IP restrictions
        tk.Label(frame, text="Allowed IPs (comma-separated, empty = all):", 
                bg='#2b2b2b', fg='#ffffff', font=('Arial', 11)).pack(anchor='w', pady=(0, 5))
        ip_entry = tk.Entry(frame, font=('Arial', 12), width=40)
        ip_entry.pack(anchor='w', pady=(0, 20))
        
        def save_settings():
            messagebox.showinfo("Settings Saved", 
                              "Client settings saved!\n\n"
                              "Note: Some settings require server restart to apply.")
            settings.destroy()
        
        btn_frame = tk.Frame(frame, bg='#2b2b2b')
        btn_frame.pack(fill=tk.X, pady=(10, 0))
        
        tk.Button(btn_frame, text="💾 Save Settings", command=save_settings,
                 bg='#4caf50', fg='white', font=('Arial', 10, 'bold'),
                 relief=tk.FLAT, cursor='hand2', padx=15, pady=5).pack(side=tk.LEFT)
        
        tk.Button(btn_frame, text="Cancel", command=settings.destroy,
                 bg='#666', fg='white', font=('Arial', 10),
                 relief=tk.FLAT, cursor='hand2', padx=15, pady=5).pack(side=tk.RIGHT)
    
    def create_tooltip(self, widget, text):
        """Create a tooltip for a widget"""
        ToolTip(widget, text)
    
    def show_help(self):
        help_window = tk.Toplevel(self.root)
        help_window.title("Help & Shortcuts")
        help_window.geometry("500x400")
        help_window.configure(bg='#2b2b2b')
        
        frame = tk.Frame(help_window, bg='#2b2b2b', padx=20, pady=20)
        frame.pack(fill=tk.BOTH, expand=True)
        
        help_text = """
╔═══════════════════════════════════════════════════════╗
║           PHAZEVPN DASHBOARD HELP                     ║
╚═══════════════════════════════════════════════════════╝

⌨️  KEYBOARD SHORTCUTS:
  • F5              - Refresh status
  • Ctrl+Q          - Logout
  • Ctrl+S          - Backup configuration
  • Double-click     - View client details

🖱️  MOUSE ACTIONS:
  • Right-click client - Context menu
  • Double-click client - View details
  • Click column headers - Sort (coming soon)

📊 FEATURES:
  • Real-time monitoring
  • Client management
  • Config editing
  • Statistics & analytics
  • Log search & filtering
  • Backup & restore

💡 TIPS:
  • Use log search to find specific events
  • Export configs to share with clients
  • Check statistics for usage patterns
  • Backup before making major changes

🔒 SECURITY:
  • Change default password!
  • Keep certificates secure
  • Regular backups recommended
        """
        
        text_widget = scrolledtext.ScrolledText(frame, bg='#1a1a1a', fg='#00ff00',
                                               font=('Courier', 10), wrap=tk.WORD)
        text_widget.pack(fill=tk.BOTH, expand=True)
        text_widget.insert(1.0, help_text)
        text_widget.config(state=tk.DISABLED)
        
        tk.Button(frame, text="Close", command=help_window.destroy,
                 bg='#666', fg='white', font=('Arial', 10),
                 relief=tk.FLAT, cursor='hand2', padx=20, pady=5).pack(pady=(10, 0))
    
    def manage_users(self):
        """User management (admin only)"""
        if not self.permissions.get('can_manage_users', False):
            messagebox.showwarning("Permission Denied", "Only administrators can manage users")
            return
        
        users_window = tk.Toplevel(self.root)
        users_window.title("User Management")
        users_window.geometry("600x500")
        users_window.configure(bg='#2b2b2b')
        
        frame = tk.Frame(users_window, bg='#2b2b2b', padx=20, pady=20)
        frame.pack(fill=tk.BOTH, expand=True)
        
        tk.Label(frame, text="👥 User Management", 
                font=('Arial', 16, 'bold'), bg='#2b2b2b', fg='#ffffff').pack(anchor='w', pady=(0, 20))
        
        # User list
        listbox_frame = tk.Frame(frame, bg='#2b2b2b')
        listbox_frame.pack(fill=tk.BOTH, expand=True, pady=(0, 15))
        
        listbox = tk.Listbox(listbox_frame, bg='#1a1a1a', fg='#ffffff',
                           font=('Courier', 11), selectbackground='#667eea')
        listbox.pack(fill=tk.BOTH, expand=True)
        
        users_data = load_users()
        for username, user_info in users_data.get("users", {}).items():
            role = user_info.get("role", "user")
            listbox.insert(tk.END, f"{username:20} [{role:10}]")
        
        def add_user():
            dialog = tk.Toplevel(users_window)
            dialog.title("Add User")
            dialog.geometry("400x250")
            dialog.configure(bg='#2b2b2b')
            
            d_frame = tk.Frame(dialog, bg='#2b2b2b', padx=20, pady=20)
            d_frame.pack(fill=tk.BOTH, expand=True)
            
            tk.Label(d_frame, text="Username:", bg='#2b2b2b', fg='#ffffff').pack(anchor='w', pady=(0, 5))
            name_entry = tk.Entry(d_frame, font=('Arial', 12), width=30)
            name_entry.pack(pady=(0, 15))
            
            tk.Label(d_frame, text="Password:", bg='#2b2b2b', fg='#ffffff').pack(anchor='w', pady=(0, 5))
            pass_entry = tk.Entry(d_frame, font=('Arial', 12), show='*', width=30)
            pass_entry.pack(pady=(0, 15))
            
            tk.Label(d_frame, text="Role:", bg='#2b2b2b', fg='#ffffff').pack(anchor='w', pady=(0, 5))
            role_var = tk.StringVar(value="user")
            role_menu = ttk.Combobox(d_frame, textvariable=role_var, 
                                    values=["admin", "moderator", "premium", "user"],
                                    state="readonly", width=27)
            role_menu.pack(pady=(0, 20))
            
            def save_user():
                username = name_entry.get().strip()
                password = pass_entry.get()
                role = role_var.get()
                
                if not username or not password:
                    messagebox.showerror("Error", "Username and password required")
                    return
                
                # Try to create user on VPS first (if API enabled)
                # Note: This requires admin session authentication which we don't have in GUI
                # So we'll create locally and note that it needs VPS sync
                users_data = load_users()
                
                # Hash password before storing
                try:
                    import bcrypt
                    hashed_password = bcrypt.hashpw(password.encode('utf-8'), bcrypt.gensalt(12)).decode('utf-8')
                except ImportError:
                    hashed_password = hash_password(password)
                
                users_data["users"][username] = {
                    "password": hashed_password,  # Store hashed password
                    "role": role,
                    "created": datetime.now().strftime("%Y-%m-%d")
                }
                
                save_users(users_data)
                
                messagebox.showinfo("Success", 
                                  f"User '{username}' added locally!\n\n"
                                  f"Note: User must be synced to VPS manually\n"
                                  f"or will be created on VPS on next login.")
                dialog.destroy()
                users_window.destroy()
                self.manage_users()  # Refresh
            
            tk.Button(d_frame, text="Add User", command=save_user,
                     bg='#4caf50', fg='white', font=('Arial', 11, 'bold'),
                     relief=tk.FLAT, cursor='hand2', padx=20, pady=8).pack()
        
        btn_frame = tk.Frame(frame, bg='#2b2b2b')
        btn_frame.pack(fill=tk.X)
        
        tk.Button(btn_frame, text="➕ Add User", command=add_user,
                 bg='#4caf50', fg='white', font=('Arial', 10, 'bold'),
                 relief=tk.FLAT, cursor='hand2', padx=15, pady=5).pack(side=tk.LEFT, padx=5)
        
        tk.Button(btn_frame, text="Close", command=users_window.destroy,
                 bg='#666', fg='white', font=('Arial', 10),
                 relief=tk.FLAT, cursor='hand2', padx=15, pady=5).pack(side=tk.RIGHT)
    
    def manage_subscription(self):
        """Open subscription management window"""
        SubscriptionWindow(self.root, self.username, self.role)
    
    def logout(self):
        if messagebox.askyesno("Logout", "Are you sure you want to logout?"):
            self.root.destroy()
    
    def run(self):
        self.root.mainloop()

class SubscriptionWindow:
    """Subscription management window - free and paid tiers"""
    def __init__(self, parent, username, role):
        self.parent = parent
        self.username = username
        self.role = role
        
        self.window = tk.Toplevel(parent)
        self.window.title("💳 PhazeVPN Subscription")
        self.window.geometry("800x700")
        self.window.configure(bg='#1a1a1a')
        
        # Get current subscription
        try:
            self.current_sub = get_user_subscription(username)
            self.current_tier = self.current_sub.get('tier', 'free')
        except:
            self.current_sub = {'tier': 'free', 'status': 'active'}
            self.current_tier = 'free'
        
        self.setup_ui()
    
    def setup_ui(self):
        # Header
        header = tk.Frame(self.window, bg='#2b2b2b', height=80)
        header.pack(fill=tk.X)
        header.pack_propagate(False)
        
        title = tk.Label(header, text="💳 PhazeVPN Subscription", 
                        bg='#2b2b2b', fg='#ffffff',
                        font=('Arial', 20, 'bold'))
        title.pack(pady=25)
        
        # Current subscription status
        status_frame = tk.Frame(self.window, bg='#2b2b2b', padx=20, pady=15)
        status_frame.pack(fill=tk.X, pady=(10, 0))
        
        try:
            tier_info = get_tier_info(self.current_tier)
        except:
            tier_info = {'name': 'Free', 'price_display': 'Free'}
        
        status_text = f"Current Plan: {tier_info.get('name', 'Free')} - {tier_info.get('price_display', 'Free')}"
        
        if self.current_tier != 'free' and self.current_sub.get('expires'):
            try:
                from datetime import datetime
                expires = self.current_sub.get('expires')
                if expires:
                    exp_date = datetime.fromisoformat(expires)
                    status_text += f"\nExpires: {exp_date.strftime('%Y-%m-%d')}"
            except:
                pass
        
        tk.Label(status_frame, text=status_text, 
                bg='#2b2b2b', fg='#00ff00',
                font=('Arial', 12, 'bold')).pack()
        
        # Subscription tiers
        tiers_frame = tk.Frame(self.window, bg='#1a1a1a', padx=20, pady=20)
        tiers_frame.pack(fill=tk.BOTH, expand=True)
        
        tk.Label(tiers_frame, text="Choose Your Plan", 
                bg='#1a1a1a', fg='#ffffff',
                font=('Arial', 16, 'bold')).pack(pady=(0, 20))
        
        # Create tier cards
        tiers_container = tk.Frame(tiers_frame, bg='#1a1a1a')
        tiers_container.pack(fill=tk.BOTH, expand=True)
        
        # Default tiers if TIERS not available
        default_tiers = {
            'free': {'name': 'Free', 'price': 0, 'price_display': 'Free', 
                    'features': ['Unlimited bandwidth', 'Unlimited connections', 'All locations']},
            'premium': {'name': 'Premium', 'price': 9.99, 'price_display': '$9.99/month',
                       'features': ['Unlimited bandwidth', 'Unlimited connections', 'Priority support', 'Advanced features']},
            'pro': {'name': 'Pro', 'price': 19.99, 'price_display': '$19.99/month',
                   'features': ['Unlimited bandwidth', 'Unlimited connections', 'Priority support', 'Dedicated support']}
        }
        
        tiers_to_show = TIERS if TIERS else default_tiers
        
        for tier_key, tier_info in tiers_to_show.items():
            self.create_tier_card(tiers_container, tier_key, tier_info)
    
    def create_tier_card(self, parent, tier_key, tier_info):
        """Create a subscription tier card"""
        card = tk.Frame(parent, bg='#2b2b2b', relief=tk.RAISED, borderwidth=2)
        card.pack(side=tk.LEFT, fill=tk.BOTH, expand=True, padx=10, pady=10)
        
        # Highlight current tier
        if tier_key == self.current_tier:
            card.configure(bg='#4a148c', relief=tk.SOLID, borderwidth=3)
        
        # Tier name
        name_frame = tk.Frame(card, bg=card['bg'], pady=15)
        name_frame.pack(fill=tk.X)
        
        tier_name = tier_info.get('name', tier_key.title())
        if tier_key == self.current_tier:
            tier_name += " ✓"
        
        tk.Label(name_frame, text=tier_name, 
                bg=card['bg'], fg='#ffffff',
                font=('Arial', 18, 'bold')).pack()
        
        # Price
        price_frame = tk.Frame(card, bg=card['bg'], pady=10)
        price_frame.pack(fill=tk.X)
        
        tk.Label(price_frame, text=tier_info.get('price_display', 'Free'), 
                bg=card['bg'], fg='#00ff00',
                font=('Arial', 24, 'bold')).pack()
        
        if tier_key != 'free':
            tk.Label(price_frame, text="/month", 
                    bg=card['bg'], fg='#aaaaaa',
                    font=('Arial', 10)).pack()
        
        # Features
        features_frame = tk.Frame(card, bg=card['bg'], padx=20, pady=15)
        features_frame.pack(fill=tk.BOTH, expand=True)
        
        features = tier_info.get('features', [])
        for feature in features:
            tk.Label(features_frame, text=f"✓ {feature}", 
                    bg=card['bg'], fg='#ffffff',
                    font=('Arial', 11),
                    anchor='w').pack(anchor='w', pady=3)
        
        # Action button
        btn_frame = tk.Frame(card, bg=card['bg'], pady=15)
        btn_frame.pack(fill=tk.X)
        
        if tier_key == self.current_tier:
            btn_text = "Current Plan"
            btn_bg = '#666'
            btn_command = None
        elif tier_key == 'free':
            btn_text = "Downgrade to Free"
            btn_bg = '#666'
            btn_command = lambda: self.change_subscription('free')
        else:
            btn_text = f"Upgrade to {tier_info.get('name', tier_key.title())}"
            btn_bg = '#9c27b0'
            btn_command = lambda t=tier_key: self.upgrade_subscription(t)
        
        btn = tk.Button(btn_frame, text=btn_text,
                       bg=btn_bg, fg='white',
                       font=('Arial', 11, 'bold'),
                       relief=tk.FLAT, cursor='hand2',
                       padx=20, pady=10,
                       command=btn_command)
        btn.pack()
    
    def upgrade_subscription(self, tier):
        """Upgrade user subscription"""
        try:
            tier_info = get_tier_info(tier)
        except:
            tier_info = {'name': tier.title(), 'price': 9.99 if tier == 'premium' else 19.99, 'price_display': f'${9.99 if tier == "premium" else 19.99}/month'}
        
        price = tier_info.get('price', 0)
        
        if price == 0:
            self.change_subscription(tier)
            return
        
        response = messagebox.askyesno(
            "Upgrade Subscription",
            f"Upgrade to {tier_info.get('name', tier.title())} for {tier_info.get('price_display', '')}?\n\n"
            f"Features:\n" + "\n".join(f"• {f}" for f in tier_info.get('features', [])) + "\n\n"
            f"Proceed to payment?",
            icon='question'
        )
        
        if response:
            try:
                payment_id = create_payment_intent(self.username, tier, price)
                self.process_payment(tier, price, payment_id)
            except:
                # Fallback if subscription manager not available
                messagebox.showinfo("Demo Mode", 
                                  f"Subscription upgrade to {tier_info.get('name', tier.title())} would be processed here.\n\n"
                                  f"In production, integrate with Stripe API for payments.")
    
    def process_payment(self, tier, amount, payment_id):
        """Process payment"""
        payment_window = tk.Toplevel(self.window)
        payment_window.title("Payment")
        payment_window.geometry("500x400")
        payment_window.configure(bg='#2b2b2b')
        
        frame = tk.Frame(payment_window, bg='#2b2b2b', padx=30, pady=30)
        frame.pack(fill=tk.BOTH, expand=True)
        
        tk.Label(frame, text="💳 Payment Processing", 
                bg='#2b2b2b', fg='#ffffff',
                font=('Arial', 16, 'bold')).pack(pady=(0, 20))
        
        tk.Label(frame, text=f"Amount: ${amount:.2f}", 
                bg='#2b2b2b', fg='#00ff00',
                font=('Arial', 14)).pack(pady=10)
        
        card_entry = tk.Entry(frame, font=('Arial', 12), width=30)
        card_entry.pack(pady=20)
        
        def complete_payment():
            try:
                record_payment(payment_id, 'completed')
                set_user_subscription(self.username, tier, payment_id)
                messagebox.showinfo("Success", 
                                  f"Payment successful!\n\n"
                                  f"You are now subscribed to {get_tier_info(tier).get('name', tier.title())}.")
            except:
                messagebox.showinfo("Demo Mode", "Payment processed (demo mode)")
            
            payment_window.destroy()
            self.window.destroy()
        
        tk.Button(frame, text="Complete Payment", 
                 command=complete_payment,
                 bg='#4caf50', fg='white',
                 font=('Arial', 12, 'bold'),
                 relief=tk.FLAT, cursor='hand2',
                 padx=30, pady=10).pack(pady=20)
        
        tk.Label(frame, text="⚠️ Demo Mode: Payment is simulated\n"
                           "In production, integrate with Stripe API",
                bg='#2b2b2b', fg='#ff9800',
                font=('Arial', 9)).pack(pady=10)
    
    def change_subscription(self, tier):
        """Change subscription tier"""
        if tier == self.current_tier:
            return
        
        if tier == 'free':
            response = messagebox.askyesno(
                "Downgrade to Free",
                "Are you sure you want to downgrade to Free?\n\n"
                "You will lose access to premium features.",
                icon='warning'
            )
            if response:
                try:
                    cancel_subscription(self.username)
                    messagebox.showinfo("Success", "Downgraded to Free plan.")
                except:
                    messagebox.showinfo("Success", "Downgraded to Free plan (demo mode).")
                self.window.destroy()
        else:
            self.upgrade_subscription(tier)

class SupportPortalWindow:
    """Discord-like chat + TeamViewer-style remote control for moderators"""
    def __init__(self, parent, moderator_name, clients):
        self.parent = parent
        self.moderator_name = moderator_name
        self.clients = clients
        self.current_client = None
        self.current_session = None
        
        self.window = tk.Toplevel(parent)
        self.window.title("💬 Support Portal - Chat & Remote Control")
        self.window.geometry("1400x900")
        self.window.configure(bg='#1a1a1a')
        
        self.setup_ui()
        self.load_clients()
    
    def setup_ui(self):
        # Main container
        main_container = tk.Frame(self.window, bg='#1a1a1a')
        main_container.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)
        
        # Left sidebar - Client list (Discord-style)
        sidebar = tk.Frame(main_container, bg='#2b2b2b', width=250)
        sidebar.pack(side=tk.LEFT, fill=tk.Y, padx=(0, 10))
        sidebar.pack_propagate(False)
        
        sidebar_header = tk.Label(sidebar, text="💬 Connected Clients", 
                                 bg='#1a1a1a', fg='#ffffff',
                                 font=('Arial', 12, 'bold'),
                                 pady=15)
        sidebar_header.pack(fill=tk.X)
        
        # Client list with scrollbar
        list_frame = tk.Frame(sidebar, bg='#2b2b2b')
        list_frame.pack(fill=tk.BOTH, expand=True, padx=5, pady=5)
        
        scrollbar = tk.Scrollbar(list_frame)
        scrollbar.pack(side=tk.RIGHT, fill=tk.Y)
        
        self.client_listbox = tk.Listbox(list_frame, bg='#1a1a1a', fg='#ffffff',
                                        font=('Arial', 11), selectbackground='#00bcd4',
                                        yscrollcommand=scrollbar.set, relief=tk.FLAT,
                                        borderwidth=0, highlightthickness=0)
        self.client_listbox.pack(fill=tk.BOTH, expand=True)
        self.client_listbox.bind('<<ListboxSelect>>', self.select_client)
        scrollbar.config(command=self.client_listbox.yview)
        
        # Middle - Chat area (Discord-style)
        chat_frame = tk.Frame(main_container, bg='#1a1a1a')
        chat_frame.pack(side=tk.LEFT, fill=tk.BOTH, expand=True, padx=(0, 10))
        
        # Chat header
        chat_header = tk.Frame(chat_frame, bg='#2b2b2b', height=50)
        chat_header.pack(fill=tk.X, pady=(0, 10))
        chat_header.pack_propagate(False)
        
        self.chat_title = tk.Label(chat_header, text="Select a client to start chatting", 
                                   bg='#2b2b2b', fg='#ffffff',
                                   font=('Arial', 14, 'bold'),
                                   padx=15)
        self.chat_title.pack(side=tk.LEFT, pady=15)
        
        # Chat messages area
        chat_messages_frame = tk.Frame(chat_frame, bg='#1a1a1a')
        chat_messages_frame.pack(fill=tk.BOTH, expand=True, pady=(0, 10))
        
        # Messages with scrollbar
        msg_scrollbar = tk.Scrollbar(chat_messages_frame)
        msg_scrollbar.pack(side=tk.RIGHT, fill=tk.Y)
        
        self.chat_messages = scrolledtext.ScrolledText(chat_messages_frame,
                                                       bg='#1a1a1a', fg='#ffffff',
                                                       font=('Arial', 11),
                                                       wrap=tk.WORD,
                                                       yscrollcommand=msg_scrollbar.set,
                                                       relief=tk.FLAT,
                                                       borderwidth=0)
        self.chat_messages.pack(fill=tk.BOTH, expand=True)
        self.chat_messages.config(state=tk.DISABLED)
        msg_scrollbar.config(command=self.chat_messages.yview)
        
        # Configure message tags for colors (Discord-style)
        self.chat_messages.tag_config('moderator', foreground='#00bcd4', font=('Arial', 11, 'bold'))
        self.chat_messages.tag_config('client', foreground='#ffffff', font=('Arial', 11))
        self.chat_messages.tag_config('system', foreground='#ff9800', font=('Arial', 10, 'italic'))
        
        # Chat input area
        input_frame = tk.Frame(chat_frame, bg='#2b2b2b', height=60)
        input_frame.pack(fill=tk.X)
        input_frame.pack_propagate(False)
        
        self.message_entry = tk.Entry(input_frame, bg='#1a1a1a', fg='#ffffff',
                                      font=('Arial', 12), relief=tk.FLAT,
                                      insertbackground='#ffffff')
        self.message_entry.pack(side=tk.LEFT, fill=tk.BOTH, expand=True, padx=10, pady=10)
        self.message_entry.bind('<Return>', lambda e: self.send_message())
        
        tk.Button(input_frame, text="Send", command=self.send_message,
                 bg='#00bcd4', fg='#000', font=('Arial', 11, 'bold'),
                 relief=tk.FLAT, cursor='hand2', padx=20, pady=10).pack(side=tk.RIGHT, padx=10)
        
        # Right panel - Remote control (TeamViewer-style)
        remote_panel = tk.LabelFrame(main_container, text="🖥️ Remote Control", 
                                     bg='#2b2b2b', fg='#ffffff',
                                     font=('Arial', 12, 'bold'),
                                     width=400)
        remote_panel.pack(side=tk.RIGHT, fill=tk.BOTH, expand=False)
        remote_panel.pack_propagate(False)
        
        # Remote screen display
        screen_frame = tk.Frame(remote_panel, bg='#000', height=300)
        screen_frame.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)
        
        self.remote_screen = tk.Label(screen_frame, text="Remote screen will appear here\n\n"
                                                         "Click 'Start Remote Control' to connect",
                                     bg='#000', fg='#666',
                                     font=('Arial', 11))
        self.remote_screen.pack(expand=True)
        
        # Remote control buttons
        control_frame = tk.Frame(remote_panel, bg='#2b2b2b')
        control_frame.pack(fill=tk.X, padx=10, pady=10)
        
        tk.Button(control_frame, text="🖥️ Start Remote Control", 
                 command=self.start_remote_control,
                 bg='#4caf50', fg='white', font=('Arial', 11, 'bold'),
                 relief=tk.FLAT, cursor='hand2', width=25, pady=8).pack(pady=5)
        
        tk.Button(control_frame, text="⏹ Stop Remote Control", 
                 command=self.stop_remote_control,
                 bg='#f44336', fg='white', font=('Arial', 11, 'bold'),
                 relief=tk.FLAT, cursor='hand2', width=25, pady=8).pack(pady=5)
        
        tk.Button(control_frame, text="📋 Request Screen Share", 
                 command=self.request_screen_share,
                 bg='#ff9800', fg='white', font=('Arial', 11, 'bold'),
                 relief=tk.FLAT, cursor='hand2', width=25, pady=8).pack(pady=5)
        
        # Connection info
        info_frame = tk.Frame(remote_panel, bg='#2b2b2b')
        info_frame.pack(fill=tk.X, padx=10, pady=10)
        
        self.connection_info = tk.Label(info_frame, text="No active connection",
                                       bg='#2b2b2b', fg='#aaa',
                                       font=('Arial', 10), justify=tk.LEFT)
        self.connection_info.pack(anchor='w')
    
    def load_clients(self):
        """Load connected VPN clients"""
        self.client_listbox.delete(0, tk.END)
        
        if not self.clients:
            self.client_listbox.insert(tk.END, "No clients connected")
            return
        
        for client in self.clients:
            client_name = client.get('name', 'Unknown')
            vpn_ip = client.get('virtual_ip', 'N/A')
            self.client_listbox.insert(tk.END, f"{client_name}\n  {vpn_ip}")
    
    def select_client(self, event):
        """Select a client to support"""
        selection = self.client_listbox.curselection()
        if not selection:
            return
        
        index = selection[0]
        if index < len(self.clients):
            self.current_client = self.clients[index]
            client_name = self.current_client.get('name', 'Unknown')
            self.chat_title.config(text=f"💬 Chatting with {client_name}")
            self.chat_messages.config(state=tk.NORMAL)
            self.chat_messages.delete(1.0, tk.END)
            self.chat_messages.insert(tk.END, f"Connected to {client_name}\n"
                                            f"VPN IP: {self.current_client.get('virtual_ip', 'N/A')}\n"
                                            f"Type a message to start chatting...\n\n")
            self.chat_messages.config(state=tk.DISABLED)
            
            self.connection_info.config(text=f"Client: {client_name}\n"
                                            f"VPN IP: {self.current_client.get('virtual_ip', 'N/A')}\n"
                                            f"Ready for remote control")
    
    def send_message(self):
        """Send chat message"""
        message = self.message_entry.get().strip()
        if not message or not self.current_client:
            return
        
        # Add message to chat
        self.chat_messages.config(state=tk.NORMAL)
        self.chat_messages.insert(tk.END, f"[{self.moderator_name}] {message}\n", 'moderator')
        self.chat_messages.config(state=tk.DISABLED)
        self.chat_messages.see(tk.END)
        
        self.message_entry.delete(0, tk.END)
        
        # In real implementation, send via socket/network to client
        # For now, simulate client response
        self.window.after(1000, lambda: self.add_client_message("Got it, thanks!"))
    
    def add_client_message(self, message):
        """Add client message to chat"""
        if not self.current_client:
            return
        
        self.chat_messages.config(state=tk.NORMAL)
        self.chat_messages.insert(tk.END, f"[{self.current_client.get('name', 'Client')}] {message}\n", 'client')
        self.chat_messages.config(state=tk.DISABLED)
        self.chat_messages.see(tk.END)
    
    def start_remote_control(self):
        """Start remote desktop control via VPN"""
        if not self.current_client:
            messagebox.showwarning("No Client", "Select a client first")
            return
        
        vpn_ip = self.current_client.get('virtual_ip')
        client_name = self.current_client.get('name')
        
        # Check if we can connect via VPN
        response = messagebox.askyesno("Remote Control", 
                                      f"Start remote control for {client_name}?\n\n"
                                      f"VPN IP: {vpn_ip}\n\n"
                                      f"This will establish a remote desktop connection\n"
                                      f"over the VPN tunnel.")
        
        if response:
            # Send request to client via VPN
            self.add_system_message(f"Requesting remote control from {client_name}...")
            
            # In production, this would:
            # 1. Send request to client's VPN IP
            # 2. Client receives and can accept/deny
            # 3. If accepted, client starts VNC server on VPN IP
            # 4. Connect via VPN IP (secure tunnel)
            # 5. Display remote screen in GUI using VNC client
            
            # For now, simulate connection
            self.window.after(2000, lambda: self.establish_remote_connection(vpn_ip, client_name))
    
    def establish_remote_connection(self, vpn_ip, client_name):
        """Establish the actual remote connection"""
        try:
            # Try to connect via VPN IP
            # This would use VNC or RDP over the VPN connection
            import socket
            test_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            test_socket.settimeout(2)
            
            # Test connection to common remote desktop ports
            ports_to_try = [5900, 3389, 5901]  # VNC, RDP, VNC alt
            
            connected = False
            for port in ports_to_try:
                try:
                    result = test_socket.connect_ex((vpn_ip, port))
                    if result == 0:
                        connected = True
                        break
                except:
                    pass
            
            test_socket.close()
            
            if connected:
                self.connection_info.config(text=f"✅ Connected to {client_name}\n"
                                                f"VPN IP: {vpn_ip}\n"
                                                f"Status: Active\n"
                                                f"Remote desktop ready")
                
                self.remote_screen.config(text=f"🖥️ Remote Desktop Active\n\n"
                                              f"Client: {client_name}\n"
                                              f"VPN IP: {vpn_ip}\n\n"
                                              f"Click and drag to control\n"
                                              f"Right-click for context menu")
                
                self.add_system_message(f"Remote control established with {client_name}")
            else:
                # Client needs to start remote desktop server
                self.connection_info.config(text=f"⚠️ Waiting for client...\n"
                                                f"VPN IP: {vpn_ip}\n"
                                                f"Client must start remote desktop\n"
                                                f"server on their end")
                
                self.remote_screen.config(text=f"Waiting for {client_name}...\n\n"
                                              f"Client needs to:\n"
                                              f"1. Accept remote control request\n"
                                              f"2. Start remote desktop server\n\n"
                                              f"VPN IP: {vpn_ip}")
                
                self.add_system_message(f"Waiting for {client_name} to accept remote control...")
                
        except Exception as e:
            messagebox.showerror("Connection Error", f"Failed to connect: {e}")
    
    def add_system_message(self, message):
        """Add system message to chat"""
        self.chat_messages.config(state=tk.NORMAL)
        self.chat_messages.insert(tk.END, f"[System] {message}\n", 'system')
        self.chat_messages.config(state=tk.DISABLED)
        self.chat_messages.see(tk.END)
    
    def stop_remote_control(self):
        """Stop remote control"""
        if self.current_client:
            self.add_system_message(f"Remote control disconnected from {self.current_client.get('name')}")
        
        self.remote_screen.config(text="Remote screen will appear here\n\n"
                                     "Click 'Start Remote Control' to connect")
        self.connection_info.config(text="No active connection")
    
    def request_screen_share(self):
        """Request client to share their screen"""
        if not self.current_client:
            messagebox.showwarning("No Client", "Select a client first")
            return
        
        client_name = self.current_client.get('name')
        self.add_system_message(f"Requesting screen share from {client_name}...")
        
        # In production, this would send a request to the client
        # Client would receive notification and can accept/deny
        # If accepted, screen stream would appear in remote_screen
        
        messagebox.showinfo("Screen Share Request", 
                          f"Screen share requested from {client_name}.\n\n"
                          f"They will receive a notification to accept.\n"
                          f"Once accepted, their screen will appear here.")
        
        # Simulate client accepting after 2 seconds
        self.window.after(2000, lambda: self.add_system_message(f"{client_name} accepted screen share"))

def main():
    # Show login
    login = LoginWindow()
    result = login.run()
    
    if not result or not result.get('logged_in', False):
        return
    
    # Show dashboard with user role
    username = result.get('username', 'admin')
    role = result.get('role', 'admin')
    
    # Get password from login if available
    password = None
    if login_result and login_result.get('logged_in'):
        # Try to get password from login window (if stored)
        # For now, we'll prompt for API login when needed
        pass
    
    app = VPNDashboard(username=username, role=role, password=password)
    app.run()

if __name__ == '__main__':
    main()

